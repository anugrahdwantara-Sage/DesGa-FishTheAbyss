# Fish The Abyss (Web Port)

2D side-scrolling action-fishing game ported from the Unity project (`DesGa-FishTheAbyss`) to React + TypeScript + HTML5 Canvas + Vite.

## Implemented Features
- **Player Movement & Physics**: Horizontal movement (`A`/`D` or Arrow keys), variable-height jumping (`Space` with fall and jump-release gravity multipliers), and platform/cave-pond AABB collision.
- **Fishing & Breach Spawning**: Press `F` to fish for 3 seconds, then spawn `Enemy1` breaching out of the depths in a parabolic arc.
- **Melee Combat & Health**: Attack with `Left Click` or `Enter` (`PlayerAttack` hitbox triggered at the animation hit frame) and track `CharacterHealth` (5 HP for player and enemies).
- **Enemy1 AI**: Horizontal detection range (`8` units), walk chase (`2` units/s), melee attack range (`1.4` units) with cooldown (`1.5s`), attack duration (`0.75s`), and hit-frame damage check.
- **Original Sprite Animations**: Uses the sliced sprite sheets from the original project for MC (`idle`, `run`, `jump`, `fall`, `attack`, `fishing`), Enemy1 (`breach`, `idle`, `walk`, `attack`), Ground platform, and animated Cave Pond.

## Running
```bash
npm install
npm run dev
```
