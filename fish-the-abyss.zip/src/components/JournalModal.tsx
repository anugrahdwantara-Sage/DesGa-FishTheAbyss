import { useState } from 'react';
import { BookOpen, X } from 'lucide-react';
import type { EnemyKind, SaveData } from '../game/types';
import { CREATURES, RARITY_META } from '../game/worldData';

interface JournalModalProps {
  save: SaveData;
  onClose: () => void;
}

const CREATURE_ORDER: EnemyKind[] = [
  'skirmisher',
  'dartfin',
  'shellback',
  'mire_eel',
  'krakor_boss',
];

export function JournalModal({ save, onClose }: JournalModalProps) {
  const [selected, setSelected] = useState<EnemyKind>('skirmisher');
  const def = CREATURES[selected];
  const entry = save.journal[selected];
  const discovered = Boolean(entry && entry.caughtCount > 0);
  const rarity = RARITY_META[def.rarity];

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-3xl bg-[#0c1424] border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-teal-400" />
            <h2 className="font-display text-lg font-bold text-slate-100">
              Abyssal Fishing Journal
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 cursor-pointer"
            aria-label="Close Journal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 min-h-[380px]">
          <div className="md:col-span-5 border-b md:border-b-0 md:border-r border-slate-800 p-4 space-y-1.5">
            {CREATURE_ORDER.map((id) => {
              const c = CREATURES[id];
              const rec = save.journal[id];
              const known = Boolean(rec && rec.caughtCount > 0);
              const active = selected === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setSelected(id)}
                  className={`w-full text-left px-3.5 py-2.5 rounded-lg transition-colors cursor-pointer flex items-center justify-between ${
                    active
                      ? 'bg-slate-800 text-slate-100'
                      : 'text-slate-300 hover:bg-slate-900'
                  }`}
                >
                  <div>
                    <div className="text-sm font-medium">
                      {known ? c.name : '??? (Uncaught)'}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {c.category} ·{' '}
                      <span style={{ color: RARITY_META[c.rarity].color }}>{c.rarity}</span>
                    </div>
                  </div>
                  <span className="font-mono-tabular text-xs text-slate-400">
                    {rec ? `×${rec.caughtCount}` : '—'}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="md:col-span-7 p-6 space-y-4">
            {discovered ? (
              <>
                <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-3">
                  <div>
                    <p className="text-xs font-semibold" style={{ color: rarity.color }}>
                      {def.rarity} · {def.category}
                    </p>
                    <h3 className="font-display text-2xl font-bold text-slate-100 mt-0.5">
                      {def.name}
                    </h3>
                  </div>
                  <div className="text-right text-xs font-mono-tabular text-slate-400">
                    <div>Caught: {entry.caughtCount}</div>
                    <div>Defeated: {entry.defeatedCount}</div>
                  </div>
                </div>

                <div className="text-xs text-slate-400 flex flex-wrap gap-x-3 gap-y-1">
                  <span>Location: {entry.firstLocation}</span>
                  <span aria-hidden="true">·</span>
                  <span>HP: {def.maxHp}</span>
                  <span aria-hidden="true">·</span>
                  <span>Reward: {def.shardReward} Shards / {def.materialDrop}</span>
                </div>

                <div className="space-y-3 text-sm text-slate-300 leading-relaxed">
                  <p>{def.description}</p>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-300 mb-1">
                      Combat Tactics
                    </h4>
                    <p className="text-slate-300 text-xs leading-relaxed">{def.combatNotes}</p>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-sky-300 mb-1">
                      Abyssal Lore
                    </h4>
                    <p className="text-slate-400 text-xs italic leading-relaxed">{def.loreNotes}</p>
                  </div>
                </div>
              </>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 py-12">
                <p className="font-display text-lg text-slate-300 mb-1">Undiscovered Specimen</p>
                <p className="text-xs max-w-xs">
                  Explore ponds across The Forgotten Shore and reel in a {def.rarity} signature to
                  record this creature in your journal.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
