import { useState } from 'react';
import { ShoppingBag, User, X } from 'lucide-react';
import type { SaveData } from '../game/types';
import { ITEMS } from '../game/worldData';

interface DialogueModalProps {
  mode: { type: 'npc'; npcName: string; npcTitle: string; lines: string[] } | { type: 'lore'; title: string; lines: string[] };
  save: SaveData;
  onBuyItem: (itemId: string) => void;
  onClose: () => void;
}

const SHOP_ITEM_IDS = [
  'rod_reinforced',
  'rod_abyssal',
  'bait_glowworm',
  'blade_upgrade',
  'vessel_shard',
];

export function DialogueModal({ mode, save, onBuyItem, onClose }: DialogueModalProps) {
  const [tab, setTab] = useState<'talk' | 'shop'>('talk');

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl bg-[#0c1424] border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <User className="w-5 h-5 text-emerald-300" />
            <div>
              <h2 className="font-display text-lg font-bold text-slate-100">
                {mode.type === 'npc' ? mode.npcName : mode.title}
              </h2>
              {mode.type === 'npc' && (
                <p className="text-xs text-slate-400">{mode.npcTitle}</p>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 cursor-pointer"
            aria-label="Close Dialogue"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {mode.type === 'npc' && (
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800">
                <button
                  type="button"
                  onClick={() => setTab('talk')}
                  className={`px-3 py-1.5 rounded text-xs font-medium cursor-pointer ${
                    tab === 'talk' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Speak
                </button>
                <button
                  type="button"
                  onClick={() => setTab('shop')}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium cursor-pointer ${
                    tab === 'shop' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  Tackle & Upgrades
                </button>
              </div>
              <span className="font-mono-tabular text-xs text-amber-300">
                {save.shards} Tide Shards
              </span>
            </div>
          )}

          {(mode.type === 'lore' || tab === 'talk') && (
            <div className="space-y-3 text-sm text-slate-300 leading-relaxed">
              {mode.lines.map((line, i) => (
                <p key={i}>{line}</p>
              ))}
            </div>
          )}

          {mode.type === 'npc' && tab === 'shop' && (
            <div className="space-y-2.5 max-h-[52vh] overflow-y-auto">
              {SHOP_ITEM_IDS.map((id) => {
                const item = ITEMS[id];
                const isSinglePurchase = item.kind === 'rod' || item.kind === 'bait';
                const owned = (save.ownedItems[id] ?? 0) > 0;
                const canAfford = save.shards >= item.cost;
                const disabled = (isSinglePurchase && owned) || !canAfford;

                return (
                  <div
                    key={id}
                    className="flex items-center justify-between gap-4 p-3 rounded-lg bg-slate-900/75 border border-slate-800"
                  >
                    <div>
                      <div className="text-sm font-medium text-slate-100">{item.name}</div>
                      <div className="text-xs text-slate-400">{item.description}</div>
                    </div>
                    <button
                      type="button"
                      disabled={disabled}
                      onClick={() => onBuyItem(id)}
                      className={`px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer ${
                        isSinglePurchase && owned
                          ? 'bg-emerald-900/40 text-emerald-300 border border-emerald-500/30 cursor-default'
                          : canAfford
                          ? 'bg-amber-600 hover:bg-amber-500 text-white'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {isSinglePurchase && owned ? 'Owned' : `Buy · ${item.cost}`}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
