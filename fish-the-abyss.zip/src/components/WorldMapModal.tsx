import { Anchor, Flame, Map as MapIcon, Skull, User, X } from 'lucide-react';
import type { RoomId, SaveData } from '../game/types';
import { ROOMS, WORLD_REGIONS_PREVIEW } from '../game/worldData';

interface WorldMapModalProps {
  save: SaveData;
  currentRoomId: RoomId;
  onClose: () => void;
}

const ROOM_LIST = Object.values(ROOMS);

export function WorldMapModal({ save, currentRoomId, onClose }: WorldMapModalProps) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-3xl bg-[#0c1424] border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <MapIcon className="w-5 h-5 text-sky-400" />
            <h2 className="font-display text-lg font-bold text-slate-100">
              Cartographer’s Map — The Forgotten Shore
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 cursor-pointer"
            aria-label="Close Map"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* 4x2 Grid of Interconnected Rooms */}
          <div className="bg-[#070b14] border border-slate-800 rounded-xl p-6">
            <div className="grid grid-cols-4 gap-4 max-w-2xl mx-auto">
              {[0, 1].map((row) =>
                [0, 1, 2, 3].map((col) => {
                  const room = ROOM_LIST.find(
                    (r) => r.mapPos.col === col && r.mapPos.row === row,
                  );
                  if (!room) {
                    return <div key={`${col}-${row}`} className="h-24" />;
                  }
                  const visited = save.visitedRooms.includes(room.id);
                  const isCurrent = room.id === currentRoomId;
                  const hasPond = room.ponds.length > 0;
                  const hasShrine = room.saveShrines.length > 0;
                  const hasNpc = room.npcs.length > 0;
                  const isBossRoom = room.id === 'boss_maw';

                  const rightExit = room.exits.find((ex) => {
                    const t = ROOMS[ex.targetRoom];
                    return t.mapPos.row === row && t.mapPos.col === col + 1;
                  });
                  const downExit = room.exits.find((ex) => {
                    const t = ROOMS[ex.targetRoom];
                    return t.mapPos.col === col && t.mapPos.row === row + 1;
                  });

                  const rightActive =
                    rightExit &&
                    (visited || save.visitedRooms.includes(rightExit.targetRoom));
                  const downActive =
                    downExit &&
                    (visited || save.visitedRooms.includes(downExit.targetRoom));

                  return (
                    <div
                      key={room.id}
                      className={`relative h-24 rounded-lg border p-2.5 flex flex-col justify-between transition-colors ${
                        isCurrent
                          ? 'bg-sky-950/60 border-sky-400'
                          : visited
                          ? 'bg-slate-900/90 border-slate-700'
                          : 'bg-slate-950/60 border-slate-800/60 opacity-55'
                      }`}
                    >
                      {rightExit && (
                        <div
                          className={`pointer-events-none absolute -right-4 top-1/2 -translate-y-1/2 w-4 h-1 ${
                            rightActive ? 'bg-sky-500/70' : 'bg-slate-800/70'
                          }`}
                          title={`${room.name} ↔ ${ROOMS[rightExit.targetRoom].name}`}
                        />
                      )}
                      {downExit && (
                        <div
                          className={`pointer-events-none absolute -bottom-4 left-1/2 -translate-x-1/2 w-1 h-4 ${
                            downActive ? 'bg-sky-400/80' : 'bg-slate-800/70'
                          }`}
                          title={`${room.name} ↔ ${ROOMS[downExit.targetRoom].name}`}
                        />
                      )}
                      <div className="text-[11px] font-semibold leading-tight text-slate-100">
                        {visited ? room.name : 'Unexplored'}
                      </div>
                      <div className="flex items-center gap-2 text-slate-300">
                        {isCurrent && (
                          <span className="text-[10px] font-mono-tabular text-sky-300">
                            YOU
                          </span>
                        )}
                        {visited && hasPond && <Anchor className="w-3.5 h-3.5 text-sky-400" />}
                        {visited && hasShrine && <Flame className="w-3.5 h-3.5 text-amber-300" />}
                        {visited && hasNpc && <User className="w-3.5 h-3.5 text-emerald-300" />}
                        {visited && isBossRoom && <Skull className="w-3.5 h-3.5 text-rose-400" />}
                      </div>
                    </div>
                  );
                }),
              )}
            </div>

            <div className="mt-5 flex flex-wrap items-center justify-center gap-5 text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <Anchor className="w-3.5 h-3.5 text-sky-400" /> Fishing Pond
              </span>
              <span className="flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-amber-300" /> Save Lantern
              </span>
              <span className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-emerald-300" /> Old Mara (Shop)
              </span>
              <span className="flex items-center gap-1.5">
                <Skull className="w-3.5 h-3.5 text-rose-400" /> Boss Maw
              </span>
            </div>
          </div>

          {/* 7-Region World Atlas Overview */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              The Abyss — World Regions
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5 text-xs">
              {WORLD_REGIONS_PREVIEW.map((reg) => (
                <div
                  key={reg.id}
                  className="flex items-center justify-between py-1 border-b border-slate-800/70"
                >
                  <span
                    className={
                      reg.id === 'forgotten_shore'
                        ? 'text-sky-300 font-medium'
                        : 'text-slate-400'
                    }
                  >
                    {reg.name}
                  </span>
                  <span className="text-slate-500">{reg.status}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
