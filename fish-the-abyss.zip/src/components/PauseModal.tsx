import { Backpack, BookOpen, LogOut, Map, Play, Save } from 'lucide-react';
import type { GameSettings } from '../game/types';

interface PauseModalProps {
  settings: GameSettings;
  onResume: () => void;
  onOpenInventory: () => void;
  onOpenMap: () => void;
  onOpenJournal: () => void;
  onSaveGame: () => void;
  onUpdateSettings: (next: GameSettings) => void;
  onReturnTitle: () => void;
}

export function PauseModal({
  settings,
  onResume,
  onOpenInventory,
  onOpenMap,
  onOpenJournal,
  onSaveGame,
  onUpdateSettings,
  onReturnTitle,
}: PauseModalProps) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm bg-[#0c1424] border border-slate-800 rounded-xl p-6 shadow-2xl space-y-5">
        <h2 className="font-display text-xl font-bold text-slate-100 text-center">Paused</h2>

        <div className="flex flex-col gap-2">
          <button
            type="button"
            onClick={onResume}
            className="flex items-center justify-center gap-2 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold cursor-pointer"
          >
            <Play className="w-4 h-4" />
            Resume
          </button>
          <button
            type="button"
            onClick={onOpenInventory}
            className="flex items-center justify-center gap-2 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium cursor-pointer"
          >
            <Backpack className="w-4 h-4 text-amber-400" />
            Inventory & Gear
          </button>
          <button
            type="button"
            onClick={onOpenMap}
            className="flex items-center justify-center gap-2 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium cursor-pointer"
          >
            <Map className="w-4 h-4 text-sky-400" />
            World Map
          </button>
          <button
            type="button"
            onClick={onOpenJournal}
            className="flex items-center justify-center gap-2 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium cursor-pointer"
          >
            <BookOpen className="w-4 h-4 text-teal-400" />
            Fishing Journal
          </button>
          <button
            type="button"
            onClick={onSaveGame}
            className="flex items-center justify-center gap-2 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium cursor-pointer"
          >
            <Save className="w-4 h-4 text-emerald-400" />
            Save Progress
          </button>
        </div>

        <div className="border-t border-slate-800 pt-4 space-y-3 text-xs text-slate-300">
          <div className="flex items-center justify-between">
            <span>Volume</span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={settings.masterVolume}
              onChange={(e) =>
                onUpdateSettings({ ...settings, masterVolume: Number(e.target.value) })
              }
              className="w-32 accent-sky-500"
            />
          </div>
          <label className="flex items-center justify-between cursor-pointer">
            <span>Hitbox Debug (H)</span>
            <input
              type="checkbox"
              checked={settings.showHitboxes}
              onChange={(e) =>
                onUpdateSettings({ ...settings, showHitboxes: e.target.checked })
              }
              className="w-4 h-4 accent-sky-500"
            />
          </label>
        </div>

        <button
          type="button"
          onClick={onReturnTitle}
          className="w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-medium cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          Return to Title Menu
        </button>
      </div>
    </div>
  );
}
