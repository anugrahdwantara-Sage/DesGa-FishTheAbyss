export interface VirtualControlsState {
  left: boolean;
  right: boolean;
  jumpHeld: boolean;
}
