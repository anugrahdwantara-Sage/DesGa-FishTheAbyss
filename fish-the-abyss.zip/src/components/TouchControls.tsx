import { Anchor, ArrowLeft, ArrowRight, ArrowUp, Heart, Swords, Wind } from 'lucide-react';
import type { VirtualControlsState } from './touchState';

interface TouchControlsProps {
  visible: boolean;
  canDash: boolean;
  canInteract: boolean;
  onChange: (updater: (prev: VirtualControlsState) => VirtualControlsState) => void;
  onTrigger: (action: 'jump' | 'attack' | 'dash' | 'fish' | 'interact' | 'heal') => void;
}

export function TouchControls({
  visible,
  canDash,
  canInteract,
  onChange,
  onTrigger,
}: TouchControlsProps) {
  if (!visible) return null;

  const setHold = (key: keyof VirtualControlsState, val: boolean) => {
    onChange((prev) => ({ ...prev, [key]: val }));
  };

  return (
    <div className="pointer-events-none absolute inset-x-3 bottom-3 z-20 flex items-end justify-between">
      {/* Left D-pad */}
      <div className="pointer-events-auto flex items-center gap-2">
        <button
          type="button"
          onPointerDown={() => setHold('left', true)}
          onPointerUp={() => setHold('left', false)}
          onPointerLeave={() => setHold('left', false)}
          className="w-12 h-12 rounded-xl bg-slate-900/75 border border-slate-700 flex items-center justify-center text-slate-100 active:bg-sky-600/70"
          aria-label="Move Left"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <button
          type="button"
          onPointerDown={() => setHold('right', true)}
          onPointerUp={() => setHold('right', false)}
          onPointerLeave={() => setHold('right', false)}
          className="w-12 h-12 rounded-xl bg-slate-900/75 border border-slate-700 flex items-center justify-center text-slate-100 active:bg-sky-600/70"
          aria-label="Move Right"
        >
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>

      {/* Right Action Cluster */}
      <div className="pointer-events-auto flex flex-wrap items-center justify-end gap-2 max-w-[230px]">
        {canInteract && (
          <button
            type="button"
            onPointerDown={() => onTrigger('interact')}
            className="h-11 px-3 rounded-xl bg-amber-600/85 border border-amber-400 text-xs font-semibold text-white"
          >
            Interact
          </button>
        )}
        <button
          type="button"
          onPointerDown={() => onTrigger('heal')}
          className="w-11 h-11 rounded-xl bg-slate-900/75 border border-slate-700 flex items-center justify-center text-emerald-300 active:bg-emerald-700/70"
          aria-label="Heal"
        >
          <Heart className="w-4 h-4" />
        </button>
        <button
          type="button"
          onPointerDown={() => onTrigger('fish')}
          className="w-11 h-11 rounded-xl bg-slate-900/75 border border-slate-700 flex items-center justify-center text-sky-300 active:bg-sky-700/70"
          aria-label="Fish"
        >
          <Anchor className="w-4 h-4" />
        </button>
        {canDash && (
          <button
            type="button"
            onPointerDown={() => onTrigger('dash')}
            className="w-11 h-11 rounded-xl bg-slate-900/75 border border-slate-700 flex items-center justify-center text-cyan-300 active:bg-cyan-700/70"
            aria-label="Dash"
          >
            <Wind className="w-4 h-4" />
          </button>
        )}
        <button
          type="button"
          onPointerDown={() => onTrigger('attack')}
          className="w-12 h-12 rounded-xl bg-slate-900/80 border border-slate-600 flex items-center justify-center text-amber-300 active:bg-amber-600/70"
          aria-label="Attack"
        >
          <Swords className="w-5 h-5" />
        </button>
        <button
          type="button"
          onPointerDown={() => {
            setHold('jumpHeld', true);
            onTrigger('jump');
          }}
          onPointerUp={() => setHold('jumpHeld', false)}
          onPointerLeave={() => setHold('jumpHeld', false)}
          className="w-12 h-12 rounded-xl bg-sky-700/85 border border-sky-400 flex items-center justify-center text-white active:bg-sky-500"
          aria-label="Jump"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
