import { Anchor, AlertTriangle, Check, X } from 'lucide-react';
import type { FishingState } from '../game/types';
import { RARITY_META } from '../game/worldData';

interface FishingOverlayProps {
  fishing: FishingState;
  onEngage: () => void;
  onRelease: () => void;
  onCancel: () => void;
}

export function FishingOverlay({
  fishing,
  onEngage,
  onRelease,
  onCancel,
}: FishingOverlayProps) {
  if (fishing.phase === 'IDLE') return null;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-end pb-20 px-4">
      {fishing.phase === 'CASTING' && (
        <div className="bg-[#0b1220]/90 border border-slate-700 rounded-lg px-5 py-3 text-xs text-sky-200 shadow-xl">
          Casting into <span className="font-semibold text-white">{fishing.pondName}</span>...
        </div>
      )}

      {fishing.phase === 'WAITING_BITE' && (
        <div className="pointer-events-auto flex items-center gap-4 bg-[#0b1220]/90 border border-slate-700 rounded-lg px-5 py-3 text-xs text-slate-200 shadow-xl">
          <Anchor className="w-4 h-4 text-sky-400" />
          <span>Waiting for a bite in {fishing.pondName}...</span>
          <button
            type="button"
            onClick={onCancel}
            className="text-slate-400 hover:text-slate-100 underline cursor-pointer"
          >
            Cancel
          </button>
        </div>
      )}

      {fishing.phase === 'BITE_WINDOW' && (
        <div className="bg-amber-950/90 border border-amber-400 rounded-lg px-6 py-3 text-sm font-bold text-amber-200 shadow-2xl flex items-center gap-2.5">
          <AlertTriangle className="w-5 h-5 text-amber-300" />
          BITE! Press [F], [Space], or [Click] NOW!
        </div>
      )}

      {fishing.phase === 'REELING' && fishing.hookedCreature && (
        <div className="w-full max-w-md bg-[#0b1220]/95 border border-slate-700 rounded-xl p-4 shadow-2xl space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-100">
              Reeling Unknown Catch
            </span>
            <span style={{ color: RARITY_META[fishing.hookedCreature.rarity].color }}>
              {fishing.hookedCreature.rarity} Signature
            </span>
          </div>

          {/* Horizontal Reeling Minigame Track */}
          <div className="relative h-8 bg-slate-900 border border-slate-700 rounded-lg overflow-hidden">
            {/* Blue Catch Bar */}
            <div
              className={`absolute top-0 bottom-0 border-x-2 transition-colors duration-100 ${
                Math.abs(fishing.fishPos - fishing.barPos) <= fishing.barHalfSize
                  ? 'bg-sky-400/40 border-sky-300'
                  : 'bg-sky-500/25 border-sky-500/80'
              }`}
              style={{
                left: `${Math.max(0, (fishing.barPos - fishing.barHalfSize) * 100)}%`,
                width: `${Math.min(100, fishing.barHalfSize * 2 * 100)}%`,
              }}
            />
            {/* Yellow Creature Circle */}
            <div
              className="absolute top-1/2 -translate-y-1/2 w-4 h-4 -ml-2 rounded-full bg-amber-400 border border-amber-200/90 shadow-[0_0_10px_rgba(251,191,36,0.75)]"
              style={{ left: `${fishing.fishPos * 100}%` }}
            />
          </div>

          <div className="grid grid-cols-2 gap-3 text-[11px]">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Catch Progress</span>
                <span className="font-mono-tabular">{Math.round(fishing.catchProgress * 100)}%</span>
              </div>
              <div className="h-2 bg-slate-800 rounded overflow-hidden">
                <div
                  className="h-full bg-emerald-400"
                  style={{ width: `${fishing.catchProgress * 100}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Line Tension</span>
                <span className="font-mono-tabular">{Math.round(fishing.tension * 100)}%</span>
              </div>
              <div className="h-2 bg-slate-800 rounded overflow-hidden">
                <div
                  className="h-full bg-rose-500"
                  style={{ width: `${fishing.tension * 100}%` }}
                />
              </div>
            </div>
          </div>

          <p className="text-[11px] text-center text-slate-400">
            Hold <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200">Space</kbd> or{' '}
            <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200">Click</kbd> to steer
            right · Release to drift left
          </p>
        </div>
      )}

      {fishing.phase === 'CATCH_REVEAL' && fishing.hookedCreature && (
        <div className="pointer-events-auto w-full max-w-md bg-[#0c1424]/95 border border-slate-700 rounded-xl p-5 shadow-2xl text-center space-y-3">
          <p
            className="text-xs font-semibold uppercase tracking-wider"
            style={{ color: RARITY_META[fishing.hookedCreature.rarity].color }}
          >
            {fishing.hookedCreature.rarity} Catch
          </p>
          <h3 className="font-display text-2xl font-bold text-slate-100">
            {fishing.hookedCreature.name}
          </h3>
          <p className="text-xs text-slate-400">{fishing.hookedCreature.description}</p>

          {fishing.hookedCreature.isBoss ? (
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={onEngage}
                className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-sm font-semibold cursor-pointer whitespace-nowrap"
              >
                <Check className="w-4 h-4" />
                Initiate Boss Fight [E]
              </button>
              <button
                type="button"
                onClick={onRelease}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium cursor-pointer whitespace-nowrap"
              >
                <X className="w-4 h-4" />
                Release Back
              </button>
            </div>
          ) : (
            <p className="text-xs text-sky-300 font-medium">
              Emerging into the arena...
            </p>
          )}
        </div>
      )}
    </div>
  );
}
