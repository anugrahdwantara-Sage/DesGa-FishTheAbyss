import { Anchor, Backpack, Check, Shield, Sparkles, Swords, X } from 'lucide-react';
import type { SaveData } from '../game/types';
import { ITEMS } from '../game/worldData';

interface InventoryModalProps {
  save: SaveData;
  onEquipRod: (id: string) => void;
  onEquipBait: (id: string) => void;
  onClose: () => void;
}

export function InventoryModal({
  save,
  onEquipRod,
  onEquipBait,
  onClose,
}: InventoryModalProps) {
  const ownedRods = Object.values(ITEMS).filter(
    (item) => item.kind === 'rod' && (save.ownedItems[item.id] ?? 0) > 0,
  );
  const ownedBaits = Object.values(ITEMS).filter(
    (item) => item.kind === 'bait' && (save.ownedItems[item.id] ?? 0) > 0,
  );
  const ownedRelics = Object.values(ITEMS).filter(
    (item) => item.kind === 'relic' && (save.ownedItems[item.id] ?? 0) > 0,
  );

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl bg-[#0c1424] border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Backpack className="w-5 h-5 text-amber-400" />
            <h2 className="font-display text-lg font-bold text-slate-100">
              Gear, Tackle & Abilities
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 cursor-pointer"
            aria-label="Close Inventory"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Combat Stats Summary */}
          <div className="flex flex-wrap items-center gap-6 text-xs text-slate-300 border-b border-slate-800 pb-4">
            <span className="flex items-center gap-1.5">
              <Swords className="w-4 h-4 text-amber-300" />
              Hook-Blade Damage: <strong className="font-mono-tabular text-white">{save.attackDamage}</strong>
            </span>
            <span className="flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-rose-400" />
              Max Health: <strong className="font-mono-tabular text-white">{save.maxHp}</strong>
            </span>
            <span className="font-mono-tabular text-amber-300">{save.shards} Tide Shards</span>
          </div>

          {/* Fishing Rods */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-sky-300 mb-2.5 flex items-center gap-1.5">
              <Anchor className="w-3.5 h-3.5" /> Fishing Rods
            </h3>
            <div className="space-y-2">
              {ownedRods.map((rod) => {
                const equipped = save.equippedRod === rod.id;
                return (
                  <div
                    key={rod.id}
                    className="flex items-center justify-between gap-4 p-3 rounded-lg bg-slate-900/70 border border-slate-800"
                  >
                    <div>
                      <div className="text-sm font-medium text-slate-100">{rod.name}</div>
                      <div className="text-xs text-slate-400">{rod.description}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onEquipRod(rod.id)}
                      disabled={equipped}
                      className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer ${
                        equipped
                          ? 'bg-sky-600/25 text-sky-300 border border-sky-500/40 cursor-default'
                          : 'bg-sky-600 hover:bg-sky-500 text-white'
                      }`}
                    >
                      {equipped ? (
                        <span className="inline-flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" /> Equipped
                        </span>
                      ) : (
                        'Equip'
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bait */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-teal-300 mb-2.5">
              Bait & Lures
            </h3>
            <div className="space-y-2">
              {ownedBaits.map((bait) => {
                const equipped = save.equippedBait === bait.id;
                return (
                  <div
                    key={bait.id}
                    className="flex items-center justify-between gap-4 p-3 rounded-lg bg-slate-900/70 border border-slate-800"
                  >
                    <div>
                      <div className="text-sm font-medium text-slate-100">{bait.name}</div>
                      <div className="text-xs text-slate-400">{bait.description}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onEquipBait(bait.id)}
                      disabled={equipped}
                      className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer ${
                        equipped
                          ? 'bg-teal-600/25 text-teal-300 border border-teal-500/40 cursor-default'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-100'
                      }`}
                    >
                      {equipped ? 'Equipped' : 'Equip'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Unlocked Movement Abilities & Relics */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-amber-300 mb-2.5 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" /> Abilities & Relics
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
              <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800">
                <div className="font-semibold text-slate-100">Wall Cling & Kick</div>
                <div className="text-emerald-300 mt-0.5">Active</div>
              </div>
              <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800">
                <div className="font-semibold text-slate-100">Abyssal Surge (Dash)</div>
                <div className={save.abilities.dash ? 'text-sky-300 mt-0.5' : 'text-slate-500 mt-0.5'}>
                  {save.abilities.dash ? 'Unlocked (Shift / L)' : 'Locked — Angler’s Watch'}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800">
                <div className="font-semibold text-slate-100">Tidal Wings (Double Jump)</div>
                <div
                  className={
                    save.abilities.doubleJump ? 'text-teal-300 mt-0.5' : 'text-slate-500 mt-0.5'
                  }
                >
                  {save.abilities.doubleJump ? 'Unlocked (Space)' : 'Locked — Sunken Grotto'}
                </div>
              </div>
            </div>

            {ownedRelics.length > 0 && (
              <div className="mt-3 space-y-2">
                {ownedRelics.map((rel) => (
                  <div
                    key={rel.id}
                    className="p-3 rounded-lg bg-amber-950/30 border border-amber-500/40"
                  >
                    <div className="text-sm font-semibold text-amber-200">{rel.name}</div>
                    <div className="text-xs text-slate-300">{rel.description}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
