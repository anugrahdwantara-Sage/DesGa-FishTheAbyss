import { Anchor, Backpack, BookOpen, Heart, Map, Pause, ShieldAlert, Sparkles } from 'lucide-react';
import type { HudSnapshot } from '../game/types';

interface GameHUDProps {
  hud: HudSnapshot;
  onOpenMap: () => void;
  onOpenJournal: () => void;
  onOpenInventory: () => void;
  onOpenPause: () => void;
}

export function GameHUD({
  hud,
  onOpenMap,
  onOpenJournal,
  onOpenInventory,
  onOpenPause,
}: GameHUDProps) {
  const canHeal = hud.essence >= 33 && hud.hp < hud.maxHp;

  return (
    <>
      <div className="pointer-events-none absolute top-3 left-3 right-3 z-10 flex items-start justify-between gap-4">
        {/* Left HUD: Health, Essence, Currencies, Equipment */}
        <div className="pointer-events-auto bg-[#0b1220]/82 border border-slate-800/90 backdrop-blur-sm rounded-lg px-4 py-2.5 shadow-lg space-y-2">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1" aria-label={`Health ${hud.hp} of ${hud.maxHp}`}>
              {Array.from({ length: hud.maxHp }).map((_, i) => (
                <Heart
                  key={i}
                  className={`w-4 h-4 ${
                    i < hud.hp
                      ? 'fill-rose-500 text-rose-400'
                      : 'fill-slate-800/80 text-slate-700'
                  }`}
                />
              ))}
            </div>
            <span className="font-mono-tabular text-xs text-slate-300">
              {hud.hp}/{hud.maxHp}
            </span>
            <span className="text-slate-600" aria-hidden="true">
              ·
            </span>
            <span className="font-mono-tabular text-xs text-amber-300">
              {hud.shards} Shards
            </span>
          </div>

          {/* Abyssal Essence / Focus Heal Bar */}
          <div className="flex items-center gap-2.5">
            <div className="w-28 h-2 bg-slate-800 rounded overflow-hidden">
              <div
                className={`h-full transition-[width] duration-150 ${
                  canHeal ? 'bg-emerald-400' : 'bg-sky-400'
                }`}
                style={{ width: `${Math.min(100, hud.essence)}%` }}
              />
            </div>
            <span className="font-mono-tabular text-[11px] text-slate-300">
              {hud.essence}/99 Essence
            </span>
            {canHeal && (
              <span className="text-[11px] font-medium text-emerald-300 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                [Q] Heal
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <Anchor className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span className="text-slate-200">{hud.equippedRodName}</span>
            <span aria-hidden="true">·</span>
            <span>{hud.equippedBaitName}</span>
            {hud.abilities.dash && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-sky-300">Dash</span>
              </>
            )}
            {hud.abilities.doubleJump && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-teal-300">Double Jump</span>
              </>
            )}
          </div>
        </div>

        {/* Right HUD: Location + Menu Actions */}
        <div className="pointer-events-auto flex flex-col items-end gap-2">
          <div className="flex items-center gap-1.5 bg-[#0b1220]/82 border border-slate-800/90 backdrop-blur-sm rounded-lg p-1.5 shadow-lg">
            <button
              type="button"
              onClick={onOpenMap}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              title="World Map (M)"
            >
              <Map className="w-3.5 h-3.5 text-sky-400" />
              Map
            </button>
            <button
              type="button"
              onClick={onOpenJournal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              title="Fishing Journal (B)"
            >
              <BookOpen className="w-3.5 h-3.5 text-teal-400" />
              Journal
            </button>
            <button
              type="button"
              onClick={onOpenInventory}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              title="Inventory & Gear (I)"
            >
              <Backpack className="w-3.5 h-3.5 text-amber-400" />
              Gear
            </button>
            <button
              type="button"
              onClick={onOpenPause}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              title="Pause (Esc)"
            >
              <Pause className="w-3.5 h-3.5 text-slate-300" />
              Menu
            </button>
          </div>

          <div className="text-right px-2 text-xs text-slate-300 drop-shadow">
            <span className="font-display font-semibold text-slate-100">{hud.roomName}</span>
            <span className="text-slate-500 mx-1.5">·</span>
            <span className="text-slate-400">{hud.regionName}</span>
            {hud.arenaLocked && (
              <span className="ml-2 inline-flex items-center gap-1 text-rose-400 font-medium">
                <ShieldAlert className="w-3.5 h-3.5" />
                Arena Locked
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Boss Health Bar */}
      {hud.bossActive && (
        <div className="pointer-events-none absolute top-24 left-1/2 -translate-x-1/2 z-10 w-full max-w-md px-4">
          <div className="bg-[#0b1220]/90 border border-rose-900/70 rounded-lg px-4 py-2.5 shadow-xl">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-display font-bold text-rose-200 tracking-wide">
                {hud.bossActive.name}
              </span>
              <span className="font-mono-tabular text-rose-300">
                Phase {hud.bossActive.phase} · {hud.bossActive.hp}/{hud.bossActive.maxHp}
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-900 rounded overflow-hidden">
              <div
                className="h-full bg-rose-500 transition-[width] duration-100"
                style={{ width: `${(hud.bossActive.hp / hud.bossActive.maxHp) * 100}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {hud.toastMessage && (
        <div className="pointer-events-none absolute top-20 left-1/2 -translate-x-1/2 z-20 px-4">
          <div className="bg-[#0c1424]/92 border border-sky-500/40 rounded-lg px-4 py-2 text-xs sm:text-sm text-slate-100 shadow-xl text-center">
            {hud.toastMessage}
          </div>
        </div>
      )}

      {/* Nearby Prompt */}
      {hud.nearbyPrompt && (
        <div className="pointer-events-none absolute bottom-16 left-1/2 -translate-x-1/2 z-10">
          <div className="bg-[#0b1220]/90 border border-sky-500/50 rounded-lg px-4 py-1.5 text-xs font-medium text-sky-200 shadow-lg whitespace-nowrap">
            {hud.nearbyPrompt.label}
          </div>
        </div>
      )}
    </>
  );
}
