import { useState } from 'react';
import { Play, RotateCcw, Settings, Sparkles, Volume2, VolumeX } from 'lucide-react';
import type { GameSettings } from '../game/types';

interface MainMenuProps {
  hasSave: boolean;
  settings: GameSettings;
  onNewGame: () => void;
  onContinue: () => void;
  onUpdateSettings: (next: GameSettings) => void;
}

export function MainMenu({
  hasSave,
  settings,
  onNewGame,
  onContinue,
  onUpdateSettings,
}: MainMenuProps) {
  const [tab, setTab] = useState<'main' | 'settings' | 'credits'>('main');

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#060a13]/92 backdrop-blur-sm p-6">
      <div className="w-full max-w-xl bg-[#0c1424] border border-slate-800 rounded-xl p-8 shadow-2xl">
        <div className="mb-8 text-center">
          <p className="text-xs font-medium tracking-[0.2em] text-sky-400/90 uppercase mb-2">
            2D Dark Fantasy Metroidvania
          </p>
          <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-wide text-slate-100">
            Fish The Abyss
          </h1>
          <p className="mt-3 text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
            No creature walks the Abyss freely. Approach ancient ponds, cast your line, reel in what
            stirs below, and survive what answers the hook.
          </p>
        </div>

        {tab === 'main' && (
          <div className="flex flex-col gap-3 max-w-xs mx-auto">
            {hasSave && (
              <button
                type="button"
                onClick={onContinue}
                className="flex items-center justify-center gap-2.5 w-full px-5 py-3 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm transition-colors cursor-pointer whitespace-nowrap"
              >
                <Play className="w-4 h-4" />
                Continue Expedition
              </button>
            )}
            <button
              type="button"
              onClick={onNewGame}
              className={`flex items-center justify-center gap-2.5 w-full px-5 py-3 rounded-lg font-semibold text-sm transition-colors cursor-pointer whitespace-nowrap ${
                hasSave
                  ? 'bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700'
                  : 'bg-sky-600 hover:bg-sky-500 text-white'
              }`}
            >
              <RotateCcw className="w-4 h-4" />
              New Game
            </button>
            <button
              type="button"
              onClick={() => setTab('settings')}
              className="flex items-center justify-center gap-2.5 w-full px-5 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
            >
              <Settings className="w-4 h-4" />
              Settings
            </button>
            <button
              type="button"
              onClick={() => setTab('credits')}
              className="flex items-center justify-center gap-2.5 w-full px-5 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
            >
              <Sparkles className="w-4 h-4" />
              World & Credits
            </button>
          </div>
        )}

        {tab === 'settings' && (
          <div className="space-y-5 max-w-sm mx-auto">
            <h2 className="font-display text-lg font-semibold text-slate-100 border-b border-slate-800 pb-2">
              Settings
            </h2>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm text-slate-300">
                <span>Master Volume</span>
                <span className="font-mono-tabular text-sky-300">
                  {settings.muted ? 'Muted' : `${Math.round(settings.masterVolume * 100)}%`}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ ...settings, muted: !settings.muted })}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
                  aria-label="Toggle Mute"
                >
                  {settings.muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.masterVolume}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, masterVolume: Number(e.target.value) })
                  }
                  className="w-full accent-sky-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-sm text-slate-300">
              <span>Touch Controls</span>
              <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800">
                {(['auto', 'on', 'off'] as const).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => onUpdateSettings({ ...settings, touchControls: mode })}
                    className={`px-3 py-1 rounded text-xs font-medium capitalize cursor-pointer ${
                      settings.touchControls === mode
                        ? 'bg-sky-600 text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>

            <label className="flex items-center justify-between text-sm text-slate-300 cursor-pointer">
              <span>Show Collision Hitboxes (H)</span>
              <input
                type="checkbox"
                checked={settings.showHitboxes}
                onChange={(e) =>
                  onUpdateSettings({ ...settings, showHitboxes: e.target.checked })
                }
                className="w-4 h-4 accent-sky-500"
              />
            </label>

            <button
              type="button"
              onClick={() => setTab('main')}
              className="w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 text-sm font-medium cursor-pointer"
            >
              Back
            </button>
          </div>
        )}

        {tab === 'credits' && (
          <div className="space-y-4 text-sm text-slate-300">
            <h2 className="font-display text-lg font-semibold text-slate-100 border-b border-slate-800 pb-2">
              About Fish The Abyss
            </h2>
            <p className="text-slate-400 leading-relaxed">
              Built on the original pixel-art character, enemy, and cavern pond assets of{' '}
              <span className="text-slate-200 font-medium">DesGa-FishTheAbyss</span>, expanded into
              an interconnected Metroidvania vertical slice featuring 6 handcrafted rooms, 3 fishable
              ponds, unlockable Dash and Double Jump abilities, NPC Tackle-Smith upgrades, a
              Fishing Journal, and the Drowned Sentinel boss encounter.
            </p>
            <div className="text-xs text-slate-400 space-y-1 border-t border-slate-800 pt-3">
              <p>Move: A / D · Jump: Space · Dash: Shift / L · Attack: Left Click / J / Enter</p>
              <p>Fish at Pond: F · Interact / Save: E · Focus Heal: Q · Map: M · Journal: J</p>
            </div>
            <button
              type="button"
              onClick={() => setTab('main')}
              className="w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 text-sm font-medium cursor-pointer"
            >
              Back
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
