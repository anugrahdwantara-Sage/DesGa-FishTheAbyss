import { useEffect, useRef, useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { DialogueModal } from './components/DialogueModal';
import { FishingOverlay } from './components/FishingOverlay';
import { GameHUD } from './components/GameHUD';
import { InventoryModal } from './components/InventoryModal';
import { JournalModal } from './components/JournalModal';
import { MainMenu } from './components/MainMenu';
import { PauseModal } from './components/PauseModal';
import { TouchControls } from './components/TouchControls';
import type { VirtualControlsState } from './components/touchState';
import { WorldMapModal } from './components/WorldMapModal';
import { loadAllSprites, type SpriteAtlas } from './game/assets';
import { soundEngine } from './game/audio';
import {
  createDefaultSave,
  type InputFrame,
  loadSavedGame,
  loadSettings,
  MetroidvaniaEngine,
  persistSettings,
} from './game/engine';
import type { GameSettings, HudSnapshot, SaveData } from './game/types';
import { ITEMS, ROOMS } from './game/worldData';

type ActiveModal =
  | { type: 'none' }
  | { type: 'pause' }
  | { type: 'map' }
  | { type: 'journal' }
  | { type: 'inventory' }
  | { type: 'npc'; npcName: string; npcTitle: string; lines: string[] }
  | { type: 'lore'; title: string; lines: string[] };

export function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<MetroidvaniaEngine | null>(null);
  const atlasRef = useRef<SpriteAtlas | null>(null);

  const [settings, setSettings] = useState<GameSettings>(() => loadSettings());
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  const [screen, setScreen] = useState<'TITLE' | 'PLAYING'>('TITLE');
  const [modal, setModal] = useState<ActiveModal>({ type: 'none' });
  const modalRef = useRef(modal);
  modalRef.current = modal;
  const screenRef = useRef(screen);
  screenRef.current = screen;

  const [hasSave, setHasSave] = useState(() => loadSavedGame() !== null);
  const [ready, setReady] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [virtualHold, setVirtualHold] = useState<VirtualControlsState>({
    left: false,
    right: false,
    jumpHeld: false,
  });
  const virtualHoldRef = useRef(virtualHold);
  virtualHoldRef.current = virtualHold;

  const queuedRef = useRef({
    jump: false,
    attack: false,
    dash: false,
    fish: false,
    interact: false,
    heal: false,
  });

  const [hud, setHud] = useState<HudSnapshot>(() => {
    const tmp = new MetroidvaniaEngine(createDefaultSave());
    return tmp.getHudSnapshot();
  });
  const [saveTick, setSaveTick] = useState(0);

  useEffect(() => {
    soundEngine.setVolume(settings.masterVolume, settings.muted);
    persistSettings(settings);
  }, [settings]);

  useEffect(() => {
    const hasTouch =
      typeof window !== 'undefined' &&
      ('ontouchstart' in window || navigator.maxTouchPoints > 0);
    setIsTouchDevice(hasTouch);
  }, []);

  const bindEngineCallbacks = (eng: MetroidvaniaEngine) => {
    eng.onOpenNpc = (npcId) => {
      const npc = eng.room.npcs.find((n) => n.id === npcId);
      if (npc) {
        setModal({
          type: 'npc',
          npcName: npc.name,
          npcTitle: npc.title,
          lines: npc.dialogue,
        });
      }
    };
    eng.onOpenLore = (title, lines) => {
      setModal({ type: 'lore', title, lines });
    };
  };

  useEffect(() => {
    let cancelled = false;
    let rafId = 0;

    const initialEngine = new MetroidvaniaEngine(loadSavedGame() ?? createDefaultSave());
    bindEngineCallbacks(initialEngine);
    engineRef.current = initialEngine;
    setHud(initialEngine.getHudSnapshot());

    const keys = new Set<string>();
    let mouseHeld = false;

    const onKeyDown = (e: KeyboardEvent) => {
      const code = e.code;
      if (
        code === 'Space' ||
        code === 'ArrowUp' ||
        code === 'ArrowDown' ||
        code === 'ArrowLeft' ||
        code === 'ArrowRight'
      ) {
        e.preventDefault();
      }

      if (screenRef.current === 'TITLE') return;

      if (!keys.has(code)) {
        if (code === 'Escape') {
          setModal((prev) => (prev.type === 'none' ? { type: 'pause' } : { type: 'none' }));
        } else if (code === 'KeyM') {
          setModal((prev) => (prev.type === 'map' ? { type: 'none' } : { type: 'map' }));
        } else if (code === 'KeyB') {
          setModal((prev) => (prev.type === 'journal' ? { type: 'none' } : { type: 'journal' }));
        } else if (code === 'KeyI') {
          setModal((prev) => (prev.type === 'inventory' ? { type: 'none' } : { type: 'inventory' }));
        } else if (code === 'KeyH') {
          setSettings((s) => ({ ...s, showHitboxes: !s.showHitboxes }));
        } else if (modalRef.current.type === 'none') {
          if (code === 'Space') queuedRef.current.jump = true;
          if (code === 'KeyJ' || code === 'Enter') queuedRef.current.attack = true;
          if (code === 'ShiftLeft' || code === 'ShiftRight' || code === 'KeyL')
            queuedRef.current.dash = true;
          if (code === 'KeyF') queuedRef.current.fish = true;
          if (code === 'KeyE') queuedRef.current.interact = true;
          if (code === 'KeyQ') queuedRef.current.heal = true;
          if (code === 'KeyR' && engineRef.current && !engineRef.current.player.alive) {
            engineRef.current.respawnAtShrine();
          }
        }
      }
      keys.add(code);
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keys.delete(e.code);
    };

    const onMouseDown = (e: MouseEvent) => {
      if (e.button === 0 && e.target === canvasRef.current && modalRef.current.type === 'none') {
        mouseHeld = true;
        queuedRef.current.attack = true;
      }
    };

    const onMouseUp = () => {
      mouseHeld = false;
    };

    const onBlur = () => {
      keys.clear();
      mouseHeld = false;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('blur', onBlur);

    loadAllSprites()
      .then((atlas) => {
        if (cancelled) return;
        atlasRef.current = atlas;
        setReady(true);

        let last = performance.now();
        let hudTimer = 0;

        const tick = (now: number) => {
          if (cancelled) return;
          const dt = (now - last) / 1000;
          last = now;

          const eng = engineRef.current;
          if (eng) {
            const paused = screenRef.current !== 'PLAYING' || modalRef.current.type !== 'none';
            if (!paused) {
              const q = queuedRef.current;
              const vh = virtualHoldRef.current;
              const input: InputFrame = {
                left: keys.has('KeyA') || keys.has('ArrowLeft') || vh.left,
                right: keys.has('KeyD') || keys.has('ArrowRight') || vh.right,
                up: keys.has('KeyW') || keys.has('ArrowUp'),
                down: keys.has('KeyS') || keys.has('ArrowDown'),
                jumpHeld:
                  keys.has('Space') ||
                  vh.jumpHeld ||
                  (eng.fishing.phase === 'REELING' && (mouseHeld || keys.has('KeyF'))),
                jumpPressed: q.jump,
                attackPressed: q.attack,
                dashPressed: q.dash,
                fishPressed: q.fish,
                interactPressed: q.interact,
                healPressed: q.heal,
              };
              q.jump = false;
              q.attack = false;
              q.dash = false;
              q.fish = false;
              q.interact = false;
              q.heal = false;

              eng.step(dt, input);
            }

            const canvas = canvasRef.current;
            if (canvas) {
              const dpr = window.devicePixelRatio || 1;
              const rect = canvas.getBoundingClientRect();
              const targetW = Math.max(1, Math.floor(rect.width * dpr));
              const targetH = Math.max(1, Math.floor(rect.height * dpr));
              if (canvas.width !== targetW || canvas.height !== targetH) {
                canvas.width = targetW;
                canvas.height = targetH;
              }
              const ctx = canvas.getContext('2d');
              if (ctx) {
                ctx.save();
                ctx.scale(dpr, dpr);
                eng.render(ctx, rect.width, rect.height, atlas, settingsRef.current.showHitboxes);
                ctx.restore();
              }
            }

            hudTimer += dt;
            const hudInterval = eng.fishing.phase === 'REELING' ? 0 : 0.05;
            if (hudTimer >= hudInterval) {
              hudTimer = 0;
              setHud(eng.getHudSnapshot());
            }
          }

          rafId = requestAnimationFrame(tick);
        };

        rafId = requestAnimationFrame(tick);
      })
      .catch((err: unknown) => {
        if (!cancelled) {
          setLoadError(err instanceof Error ? err.message : 'Failed to load sprites');
        }
      });

    return () => {
      cancelled = true;
      cancelAnimationFrame(rafId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('blur', onBlur);
    };
  }, []);

  const startNewGame = () => {
    soundEngine.startAmbience();
    const freshSave = createDefaultSave();
    const eng = new MetroidvaniaEngine(freshSave);
    bindEngineCallbacks(eng);
    eng.writeSave();
    engineRef.current = eng;
    setHasSave(true);
    setModal({ type: 'none' });
    setScreen('PLAYING');
    setHud(eng.getHudSnapshot());
  };

  const continueGame = () => {
    soundEngine.startAmbience();
    const loaded = loadSavedGame();
    if (loaded) {
      const eng = new MetroidvaniaEngine(loaded);
      bindEngineCallbacks(eng);
      engineRef.current = eng;
      setHud(eng.getHudSnapshot());
    }
    setModal({ type: 'none' });
    setScreen('PLAYING');
  };

  const handleEquipRod = (id: string) => {
    const eng = engineRef.current;
    if (!eng) return;
    eng.save.equippedRod = id;
    eng.writeSave();
    setSaveTick((t) => t + 1);
    setHud(eng.getHudSnapshot());
  };

  const handleEquipBait = (id: string) => {
    const eng = engineRef.current;
    if (!eng) return;
    eng.save.equippedBait = id;
    eng.writeSave();
    setSaveTick((t) => t + 1);
    setHud(eng.getHudSnapshot());
  };

  const handleBuyItem = (itemId: string) => {
    const eng = engineRef.current;
    const item = ITEMS[itemId];
    if (!eng || !item || eng.save.shards < item.cost) return;

    eng.save.shards -= item.cost;
    if (item.kind === 'rod') {
      eng.save.ownedItems[item.id] = 1;
      eng.save.equippedRod = item.id;
    } else if (item.kind === 'bait') {
      eng.save.ownedItems[item.id] = 1;
      eng.save.equippedBait = item.id;
    } else if (item.kind === 'blade') {
      eng.save.attackDamage += item.damageBonus ?? 1;
    } else if (item.kind === 'vessel') {
      eng.save.maxHp += item.hpBonus ?? 1;
      eng.save.hp = eng.save.maxHp;
    }

    soundEngine.catchSuccess();
    eng.writeSave();
    setSaveTick((t) => t + 1);
    setHud(eng.getHudSnapshot());
  };

  const showTouch =
    screen === 'PLAYING' &&
    modal.type === 'none' &&
    (settings.touchControls === 'on' || (settings.touchControls === 'auto' && isTouchDevice));

  const currentSave: SaveData = engineRef.current?.save ?? createDefaultSave();
  void saveTick;

  return (
    <div className="relative w-screen h-screen bg-[#070b14] overflow-hidden">
      <canvas ref={canvasRef} className="block w-full h-full cursor-crosshair" />

      {!ready && !loadError && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#070b14] text-sm font-mono-tabular text-slate-300">
          Loading The Forgotten Shore...
        </div>
      )}

      {loadError && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#070b14] p-6">
          <div className="max-w-md bg-slate-900 border border-rose-500/40 rounded-xl p-6 text-center">
            <p className="font-semibold text-rose-300 mb-1">Failed to initialize sprites</p>
            <p className="text-xs font-mono-tabular text-slate-400">{loadError}</p>
          </div>
        </div>
      )}

      {ready && screen === 'TITLE' && (
        <MainMenu
          hasSave={hasSave}
          settings={settings}
          onNewGame={startNewGame}
          onContinue={continueGame}
          onUpdateSettings={setSettings}
        />
      )}

      {ready && screen === 'PLAYING' && (
        <>
          <GameHUD
            hud={hud}
            onOpenMap={() => setModal({ type: 'map' })}
            onOpenJournal={() => setModal({ type: 'journal' })}
            onOpenInventory={() => setModal({ type: 'inventory' })}
            onOpenPause={() => setModal({ type: 'pause' })}
          />

          <FishingOverlay
            fishing={hud.fishing}
            onEngage={() => engineRef.current?.engageHookedCreature()}
            onRelease={() => engineRef.current?.releaseHookedCreature()}
            onCancel={() => engineRef.current?.cancelFishing()}
          />

          {/* Compact Desktop Controls Footer */}
          {!showTouch && (
            <div className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 z-10 hidden sm:flex items-center gap-3.5 bg-[#0b1220]/75 border border-slate-800/80 backdrop-blur-sm rounded-lg px-4 py-1.5 text-[11px] text-slate-300">
              <span>A / D Move</span>
              <span className="text-slate-600">·</span>
              <span>Space Jump / Wall-Kick</span>
              {hud.abilities.dash && (
                <>
                  <span className="text-slate-600">·</span>
                  <span className="text-sky-300">Shift Dash</span>
                </>
              )}
              <span className="text-slate-600">·</span>
              <span>Click / J Attack</span>
              <span className="text-slate-600">·</span>
              <span className="text-sky-300">F Fish</span>
              <span className="text-slate-600">·</span>
              <span>E Interact</span>
            </div>
          )}

          <TouchControls
            visible={showTouch}
            canDash={hud.abilities.dash}
            canInteract={Boolean(hud.nearbyPrompt && hud.nearbyPrompt.action !== 'fish')}
            onChange={setVirtualHold}
            onTrigger={(action) => {
              if (action === 'jump') queuedRef.current.jump = true;
              if (action === 'attack') queuedRef.current.attack = true;
              if (action === 'dash') queuedRef.current.dash = true;
              if (action === 'fish') queuedRef.current.fish = true;
              if (action === 'interact') queuedRef.current.interact = true;
              if (action === 'heal') queuedRef.current.heal = true;
            }}
          />
        </>
      )}

      {/* Modals */}
      {screen === 'PLAYING' && modal.type === 'map' && (
        <WorldMapModal
          save={currentSave}
          currentRoomId={hud.roomId ?? ROOMS.shore_landing.id}
          onClose={() => setModal({ type: 'none' })}
        />
      )}

      {screen === 'PLAYING' && modal.type === 'journal' && (
        <JournalModal save={currentSave} onClose={() => setModal({ type: 'none' })} />
      )}

      {screen === 'PLAYING' && modal.type === 'inventory' && (
        <InventoryModal
          save={currentSave}
          onEquipRod={handleEquipRod}
          onEquipBait={handleEquipBait}
          onClose={() => setModal({ type: 'none' })}
        />
      )}

      {screen === 'PLAYING' && (modal.type === 'npc' || modal.type === 'lore') && (
        <DialogueModal
          mode={modal}
          save={currentSave}
          onBuyItem={handleBuyItem}
          onClose={() => setModal({ type: 'none' })}
        />
      )}

      {screen === 'PLAYING' && modal.type === 'pause' && (
        <PauseModal
          settings={settings}
          onResume={() => setModal({ type: 'none' })}
          onOpenInventory={() => setModal({ type: 'inventory' })}
          onOpenMap={() => setModal({ type: 'map' })}
          onOpenJournal={() => setModal({ type: 'journal' })}
          onSaveGame={() => {
            engineRef.current?.writeSave();
            engineRef.current?.showToast('Progress saved.');
            setHasSave(true);
            setModal({ type: 'none' });
          }}
          onUpdateSettings={setSettings}
          onReturnTitle={() => {
            engineRef.current?.writeSave();
            setHasSave(true);
            setModal({ type: 'none' });
            setScreen('TITLE');
          }}
        />
      )}

      {/* Defeat / Respawn Overlay */}
      {ready && screen === 'PLAYING' && !hud.alive && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-[#0c1424] border border-slate-800 rounded-xl p-6 text-center shadow-2xl space-y-4">
            <h2 className="font-display text-2xl font-bold text-rose-400">
              {hud.fellInAbyss ? 'Lost to the Abyss' : 'Lantern Extinguished'}
            </h2>
            <p className="text-sm text-slate-300">
              Return to your last Tide Lantern shrine with your discovered journal, gear, and
              abilities intact.
            </p>
            <button
              type="button"
              onClick={() => {
                engineRef.current?.respawnAtShrine();
                if (engineRef.current) setHud(engineRef.current.getHudSnapshot());
              }}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              Awaken at Tide Lantern (R)
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
