import {
  ENEMY_ANIMS,
  MC_ANIMS,
  type EnemyAnimName,
  type McAnimName,
  type SpriteAtlas,
  WORLD_SPRITES,
  sampleClipFrame,
} from './assets';
import { soundEngine } from './audio';
import type {
  AABB,
  CreatureDefinition,
  FishingState,
  GameSettings,
  HudSnapshot,
  PondConfig,
  RoomConfig,
  RoomId,
  SaveData,
} from './types';
import { CREATURES, ITEMS, ROOMS } from './worldData';

const SAVE_KEY = 'fish_the_abyss_save_v1';
const SETTINGS_KEY = 'fish_the_abyss_settings_v1';
const GRAVITY = -9.81;
const PIXELS_PER_UNIT = 100;
const CAMERA_ORTHO_SIZE = 5;

const MC_CFG = {
  scaleX: 0.6383,
  scaleY: 0.598,
  colOffsetX: 0,
  colOffsetY: -0.09,
  colSizeX: 0.56,
  colSizeY: 1.27,
  moveSpeed: 6.2,
  jumpForce: 12.6,
  gravityScale: 2.5,
  fallGravMult: 1.7,
  releaseGravMult: 2.0,
  coyoteTime: 0.11,
  jumpBuffer: 0.12,
  dashSpeed: 15.0,
  dashDuration: 0.18,
  dashCooldown: 0.45,
  wallSlideMaxFall: -2.8,
  wallJumpVx: 7.4,
  wallJumpVy: 11.8,
  attackDuration: 0.34,
  attackCooldown: 0.28,
  attackOffsetX: 1.25,
  attackOffsetY: -0.22,
  attackSizeX: 2.35,
  attackSizeY: 0.92,
};

export interface InputFrame {
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  jumpHeld: boolean;
  jumpPressed: boolean;
  attackPressed: boolean;
  dashPressed: boolean;
  fishPressed: boolean;
  interactPressed: boolean;
  healPressed: boolean;
}

interface ActiveEnemy {
  id: number;
  def: CreatureDefinition;
  x: number;
  y: number;
  vx: number;
  vy: number;
  flipX: boolean;
  grounded: boolean;
  hp: number;
  maxHp: number;
  isBreaching: boolean;
  breachElapsed: number;
  breachStartX: number;
  breachStartY: number;
  breachEndX: number;
  breachEndY: number;
  attackTimer: number;
  attackCooldownTimer: number;
  attackEventFired: boolean;
  anim: EnemyAnimName;
  animTime: number;
  hitFlashTimer: number;
  phase: number;
  specialTimer: number;
  telegraphType: 'none' | 'slam' | 'lunge' | 'geyser';
}

interface Projectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  damage: number;
  color: string;
  life: number;
  fromEnemy: boolean;
}

interface GeyserHazard {
  x: number;
  y: number;
  warnTimer: number;
  activeTimer: number;
  hitPlayer: boolean;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
}

interface FloatingText {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
}

function aabbOverlap(a: AABB, b: AABB): boolean {
  return (
    Math.abs(a.x - b.x) < (a.w + b.w) * 0.5 &&
    Math.abs(a.y - b.y) < (a.h + b.h) * 0.5
  );
}

export function createDefaultSave(): SaveData {
  return {
    version: 1,
    roomId: 'shore_landing',
    respawnRoomId: 'shore_landing',
    respawnX: -0.2,
    respawnY: -1.35,
    hp: 5,
    maxHp: 5,
    essence: 0,
    shards: 0,
    abilities: {
      dash: false,
      doubleJump: false,
      wallCling: true,
    },
    equippedRod: 'rod_basic',
    equippedBait: 'bait_none',
    ownedItems: { rod_basic: 1, bait_none: 1 },
    attackDamage: 1,
    brokenWalls: [],
    collectedPickups: [],
    visitedRooms: ['shore_landing'],
    discoveredPonds: [],
    defeatedBosses: [],
    journal: {},
  };
}

export function loadSavedGame(): SaveData | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SaveData;
    if (parsed && parsed.version === 1 && ROOMS[parsed.roomId]) {
      return parsed;
    }
  } catch {
    return null;
  }
  return null;
}

export function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) {
      return {
        masterVolume: 0.55,
        muted: false,
        showHitboxes: false,
        touchControls: 'auto',
        ...JSON.parse(raw),
      };
    }
  } catch {
    // ignore
  }
  return {
    masterVolume: 0.55,
    muted: false,
    showHitboxes: false,
    touchControls: 'auto',
  };
}

export function persistSettings(settings: GameSettings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // ignore
  }
}

export class MetroidvaniaEngine {
  save: SaveData;
  room: RoomConfig;
  player = {
    x: -0.2,
    y: -1.35,
    vx: 0,
    vy: 0,
    flipX: false,
    grounded: false,
    wallDir: 0 as -1 | 0 | 1,
    coyoteTimer: 0,
    jumpBufferTimer: 0,
    airJumpsLeft: 0,
    dashTimer: 0,
    dashCooldownTimer: 0,
    dashDir: 1,
    isAttacking: false,
    attackTimer: 0,
    attackCooldownTimer: 0,
    attackEventFired: false,
    invulnTimer: 0,
    hitFlashTimer: 0,
    anim: 'idle' as McAnimName,
    animTime: 0,
    alive: true,
    fellInAbyss: false,
  };

  fishing: FishingState = {
    phase: 'IDLE',
    pondId: null,
    pondName: '',
    timer: 0,
    biteTimer: 0,
    hookedCreature: null,
    barPos: 0.5,
    barVel: 0,
    barHalfSize: 0.14,
    fishPos: 0.5,
    fishVel: 0,
    fishTarget: 0.5,
    fishMoveTimer: 0,
    catchProgress: 0.25,
    tension: 0,
  };

  // CRITICAL: always empty on room entry; enemies ONLY originate from fishing!
  enemies: ActiveEnemy[] = [];
  projectiles: Projectile[] = [];
  geysers: GeyserHazard[] = [];
  particles: Particle[] = [];
  floatingTexts: FloatingText[] = [];
  dashAfterimages: { x: number; y: number; flipX: boolean; alpha: number }[] = [];

  camX = 0;
  camY = 0;
  shakeTimer = 0;
  shakeIntensity = 0;
  transitionAlpha = 0;
  worldTime = 0;
  nextEnemyId = 1;
  toastMessage: string | null = null;
  toastTimer = 0;

  onOpenNpc?: (npcId: string) => void;
  onOpenLore?: (title: string, lines: string[]) => void;

  constructor(initialSave?: SaveData) {
    this.save = initialSave ? structuredClone(initialSave) : createDefaultSave();
    this.room = ROOMS[this.save.roomId] ?? ROOMS.shore_landing;
    this.player.x = this.save.respawnX;
    this.player.y = this.save.respawnY;
    this.snapCamera();
  }

  writeSave() {
    this.save.roomId = this.room.id;
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.save));
    } catch {
      // ignore
    }
  }

  showToast(msg: string, duration = 2.6) {
    this.toastMessage = msg;
    this.toastTimer = duration;
  }

  private snapCamera() {
    const b = this.room.bounds;
    const halfH = CAMERA_ORTHO_SIZE;
    const halfW = CAMERA_ORTHO_SIZE * 1.777;
    this.camX = Math.max(b.minX + halfW * 0.45, Math.min(b.maxX - halfW * 0.45, this.player.x));
    this.camY = Math.max(b.minY + halfH * 0.5, Math.min(b.maxY - halfH * 0.5, this.player.y + 0.6));
  }

  private getRoomSolids(): AABB[] {
    const walls = this.room.breakableWalls
      .filter((w) => !this.save.brokenWalls.includes(w.id))
      .map((w) => ({ x: w.x, y: w.y, w: w.w, h: w.h }));
    return [...this.room.colliders, ...walls];
  }

  private getPlayerCollider(x = this.player.x, y = this.player.y): AABB {
    return {
      x: x + MC_CFG.colOffsetX * MC_CFG.scaleX,
      y: y + MC_CFG.colOffsetY * MC_CFG.scaleY,
      w: MC_CFG.colSizeX * MC_CFG.scaleX,
      h: MC_CFG.colSizeY * MC_CFG.scaleY,
    };
  }

  private getPlayerAttackBox(): AABB {
    const dir = this.player.flipX ? -1 : 1;
    return {
      x: this.player.x + dir * MC_CFG.attackOffsetX * MC_CFG.scaleX,
      y: this.player.y + MC_CFG.attackOffsetY * MC_CFG.scaleY,
      w: MC_CFG.attackSizeX * MC_CFG.scaleX,
      h: MC_CFG.attackSizeY * MC_CFG.scaleY,
    };
  }

  private getEnemyCollider(e: ActiveEnemy, x = e.x, y = e.y): AABB {
    const scale = e.def.isBoss ? 1.55 : 1.0;
    return {
      x,
      y,
      w: 0.72 * scale,
      h: 1.05 * scale,
    };
  }

  private getEnemyAttackBox(e: ActiveEnemy): AABB {
    const dir = e.flipX ? -1 : 1;
    const reach = e.def.isBoss ? 1.45 : 0.8;
    const w = e.def.isBoss ? 2.2 : 1.45;
    const h = e.def.isBoss ? 1.4 : 0.75;
    return { x: e.x + dir * reach, y: e.y, w, h };
  }

  private setPlayerAnim(name: McAnimName) {
    if (this.player.anim !== name) {
      this.player.anim = name;
      this.player.animTime = 0;
    }
  }

  private setEnemyAnim(e: ActiveEnemy, name: EnemyAnimName) {
    if (e.anim !== name) {
      e.anim = name;
      e.animTime = 0;
    }
  }

  private spawnParticles(x: number, y: number, color: string, count: number, speed = 3.2) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = (0.3 + Math.random() * 0.7) * speed;
      const maxLife = 0.25 + Math.random() * 0.35;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd + 1.0,
        size: 2 + Math.random() * 3,
        color,
        life: maxLife,
        maxLife,
      });
    }
  }

  private moveWithSolids(
    x: number,
    y: number,
    vx: number,
    vy: number,
    dt: number,
    solids: AABB[],
    getBox: (cx: number, cy: number) => AABB,
  ) {
    let nextX = x + vx * dt;
    let nextVx = vx;
    let wallDir: -1 | 0 | 1 = 0;

    const boxX = getBox(nextX, y);
    for (const s of solids) {
      if (aabbOverlap(boxX, s)) {
        const halfW = (boxX.w + s.w) * 0.5;
        if (vx > 0) {
          nextX = s.x - halfW - (boxX.x - nextX) - 0.0005;
          wallDir = 1;
        } else if (vx < 0) {
          nextX = s.x + halfW - (boxX.x - nextX) + 0.0005;
          wallDir = -1;
        }
        nextVx = 0;
        break;
      }
    }

    // Check wall proximity even if horizontal input stopped
    if (wallDir === 0) {
      const rightProbe = getBox(nextX + 0.03, y);
      const leftProbe = getBox(nextX - 0.03, y);
      for (const s of solids) {
        if (aabbOverlap(rightProbe, s)) {
          wallDir = 1;
          break;
        }
        if (aabbOverlap(leftProbe, s)) {
          wallDir = -1;
          break;
        }
      }
    }

    let nextY = y + vy * dt;
    let nextVy = vy;
    let grounded = false;
    const boxY = getBox(nextX, nextY);
    for (const s of solids) {
      if (aabbOverlap(boxY, s)) {
        const halfH = (boxY.h + s.h) * 0.5;
        if (vy <= 0) {
          nextY = s.y + halfH - (boxY.y - nextY);
          grounded = true;
        } else {
          nextY = s.y - halfH - (boxY.y - nextY) - 0.0005;
        }
        nextVy = 0;
        break;
      }
    }

    if (!grounded && nextVy <= 0) {
      const groundProbe = getBox(nextX, nextY - 0.02);
      for (const s of solids) {
        if (aabbOverlap(groundProbe, s)) {
          grounded = true;
          break;
        }
      }
    }

    return { x: nextX, y: nextY, vx: nextVx, vy: nextVy, grounded, wallDir };
  }

  private getNearbyPond(): PondConfig | null {
    const px = this.player.x;
    const py = this.player.y;
    for (const pond of this.room.ponds) {
      if (
        Math.abs(px - pond.zoneX) <= pond.zoneW * 0.5 &&
        Math.abs(py - pond.zoneY) <= pond.zoneH * 0.5
      ) {
        if (!this.save.discoveredPonds.includes(pond.id)) {
          this.save.discoveredPonds.push(pond.id);
        }
        return pond;
      }
    }
    return null;
  }

  private getNearbyPrompt(): HudSnapshot['nearbyPrompt'] {
    if (this.enemies.length > 0 || this.fishing.phase !== 'IDLE') return null;

    const px = this.player.x;
    const py = this.player.y;

    for (const pickup of this.room.pickups) {
      if (this.save.collectedPickups.includes(pickup.id)) continue;
      if (Math.hypot(px - pickup.x, py - pickup.y) < 1.25) {
        return { label: `[E] Claim ${pickup.title}`, action: 'pickup' };
      }
    }

    for (const npc of this.room.npcs) {
      if (Math.hypot(px - npc.x, py - npc.y) < 1.65) {
        return { label: `[E] Speak with ${npc.name}`, action: 'npc' };
      }
    }

    for (const shrine of this.room.saveShrines) {
      if (Math.hypot(px - shrine.x, py - shrine.y) < 1.35) {
        return { label: `[E] Rest & Save at Lantern`, action: 'save' };
      }
    }

    for (const tablet of this.room.loreTablets) {
      if (Math.hypot(px - tablet.x, py - tablet.y) < 1.35) {
        return { label: `[E] Read ${tablet.title}`, action: 'lore' };
      }
    }

    const pond = this.getNearbyPond();
    if (pond) {
      return { label: `[F] Cast Line · ${pond.name}`, action: 'fish' };
    }

    return null;
  }

  private rollPondCreature(pond: PondConfig): CreatureDefinition {
    const rod = ITEMS[this.save.equippedRod] ?? ITEMS.rod_basic;
    const bait = ITEMS[this.save.equippedBait] ?? ITEMS.bait_none;
    const rodLevel = rod.rodLevel ?? 1;
    const rareMult = 1 + (rod.rareBonus ?? 0) + (bait.rareBonus ?? 0);

    const eligible = pond.pool.filter((entry) => rodLevel >= entry.minRodLevel);
    const weighted = eligible.map((entry) => {
      const def = CREATURES[entry.creatureId];
      const boost = def.rarity === 'Common' ? 1 : rareMult;
      return { def, w: entry.weight * boost };
    });

    const total = weighted.reduce((acc, item) => acc + item.w, 0);
    let roll = Math.random() * total;
    for (const item of weighted) {
      roll -= item.w;
      if (roll <= 0) return item.def;
    }
    return weighted[0].def;
  }

  engageHookedCreature() {
    if (this.fishing.phase !== 'CATCH_REVEAL' || !this.fishing.hookedCreature) return;
    const def = this.fishing.hookedCreature;
    const pond = this.room.ponds.find((p) => p.id === this.fishing.pondId) ?? this.room.ponds[0];

    // Record discovery in Fishing Journal
    const existing = this.save.journal[def.id] ?? {
      caughtCount: 0,
      defeatedCount: 0,
      firstLocation: pond ? `${pond.name} (${this.room.name})` : this.room.name,
    };
    existing.caughtCount += 1;
    this.save.journal[def.id] = existing;

    // Spawn enemy breaching from the pond surface!
    const pondCenterX = pond ? pond.x : this.player.x + (this.player.flipX ? -1.4 : 1.4);
    const landingX = Math.max(
      this.room.bounds.minX + 2.5,
      Math.min(this.room.bounds.maxX - 2.5, (this.player.x + pondCenterX) * 0.5),
    );
    const landingY = -1.45;
    const spawnY = landingY - 1.9;

    if (def.isBoss) {
      soundEngine.bossRoar();
      this.shakeTimer = 0.45;
      this.shakeIntensity = 0.22;
    } else {
      soundEngine.castSplash();
    }

    this.spawnParticles(landingX, -2.0, def.isBoss ? '#fb7185' : '#38bdf8', 22, 5.0);

    this.enemies.push({
      id: this.nextEnemyId++,
      def,
      x: landingX,
      y: spawnY,
      vx: 0,
      vy: 0,
      flipX: this.player.x < landingX,
      grounded: false,
      hp: def.maxHp,
      maxHp: def.maxHp,
      isBreaching: true,
      breachElapsed: 0,
      breachStartX: landingX,
      breachStartY: spawnY,
      breachEndX: landingX,
      breachEndY: landingY,
      attackTimer: 0,
      attackCooldownTimer: 0.6,
      attackEventFired: false,
      anim: 'breach',
      animTime: 0,
      hitFlashTimer: 0,
      phase: 1,
      specialTimer: 2.2,
      telegraphType: 'none',
    });

    this.fishing.phase = 'IDLE';
    this.fishing.hookedCreature = null;
    this.setPlayerAnim('idle');
    this.writeSave();
  }

  releaseHookedCreature() {
    if (this.fishing.phase !== 'CATCH_REVEAL') return;
    this.showToast('Released catch back into the dark water.');
    this.fishing.phase = 'IDLE';
    this.fishing.hookedCreature = null;
    this.setPlayerAnim('idle');
  }

  cancelFishing() {
    if (this.fishing.phase === 'IDLE') return;
    this.fishing.phase = 'IDLE';
    this.fishing.hookedCreature = null;
    this.setPlayerAnim('idle');
  }

  respawnAtShrine() {
    const targetRoom = ROOMS[this.save.respawnRoomId] ?? ROOMS.shore_landing;
    this.room = targetRoom;
    this.save.roomId = targetRoom.id;
    this.save.hp = this.save.maxHp;
    this.player.x = this.save.respawnX;
    this.player.y = this.save.respawnY;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.alive = true;
    this.player.fellInAbyss = false;
    this.player.invulnTimer = 1.0;
    this.enemies = [];
    this.projectiles = [];
    this.geysers = [];
    this.fishing.phase = 'IDLE';
    this.fishing.hookedCreature = null;
    this.transitionAlpha = 0.8;
    this.snapCamera();
  }

  private transitionToRoom(roomId: RoomId, spawnX: number, spawnY: number) {
    this.room = ROOMS[roomId];
    this.save.roomId = roomId;
    if (!this.save.visitedRooms.includes(roomId)) {
      this.save.visitedRooms.push(roomId);
    }
    this.player.x = spawnX;
    this.player.y = spawnY;
    this.player.vx = 0;
    this.player.vy = 0;
    this.enemies = []; // NEVER carry or spawn natural enemies across rooms!
    this.projectiles = [];
    this.geysers = [];
    this.particles = [];
    this.dashAfterimages = [];
    this.transitionAlpha = 0.9;
    this.snapCamera();
    this.writeSave();
  }

  step(dt: number, input: InputFrame) {
    const cDt = Math.min(dt, 0.045);
    this.worldTime += cDt;

    if (this.transitionAlpha > 0) {
      this.transitionAlpha = Math.max(0, this.transitionAlpha - cDt * 3.2);
    }
    if (this.shakeTimer > 0) {
      this.shakeTimer = Math.max(0, this.shakeTimer - cDt);
    }
    if (this.toastTimer > 0) {
      this.toastTimer -= cDt;
      if (this.toastTimer <= 0) this.toastMessage = null;
    }

    this.updateParticlesAndTexts(cDt);

    if (!this.player.alive) return;

    if (this.fishing.phase !== 'IDLE') {
      this.updateFishing(cDt, input);
      this.updateCamera(cDt);
      return;
    }

    this.updatePlayer(cDt, input);
    this.updateEnemies(cDt);
    this.updateProjectilesAndGeysers(cDt);
    this.checkExits();
    this.updateCamera(cDt);
  }

  private updateParticlesAndTexts(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy -= 5.5 * dt;
      p.life -= dt;
      if (p.life <= 0) this.particles.splice(i, 1);
    }
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const f = this.floatingTexts[i];
      f.y += 1.0 * dt;
      f.life -= dt;
      if (f.life <= 0) this.floatingTexts.splice(i, 1);
    }
    for (let i = this.dashAfterimages.length - 1; i >= 0; i--) {
      this.dashAfterimages[i].alpha -= dt * 4.5;
      if (this.dashAfterimages[i].alpha <= 0) this.dashAfterimages.splice(i, 1);
    }
  }

  private updateFishing(dt: number, input: InputFrame) {
    const f = this.fishing;
    this.player.vx = 0;
    this.player.animTime += dt;

    if (f.phase === 'CASTING') {
      f.timer -= dt;
      if (f.timer <= 0) {
        soundEngine.castSplash();
        f.phase = 'WAITING_BITE';
        f.biteTimer = 1.0 + Math.random() * 1.4;
      }
      return;
    }

    if (f.phase === 'WAITING_BITE') {
      f.biteTimer -= dt;
      if (input.fishPressed && f.biteTimer > 0.1) {
        this.showToast('Pulled too early—nothing hooked.');
        this.cancelFishing();
        return;
      }
      if (f.biteTimer <= 0) {
        soundEngine.biteAlert();
        f.phase = 'BITE_WINDOW';
        f.timer = 1.25;
      }
      return;
    }

    if (f.phase === 'BITE_WINDOW') {
      f.timer -= dt;
      if (input.fishPressed || input.jumpPressed || input.attackPressed) {
        const pond = this.room.ponds.find((p) => p.id === f.pondId);
        if (!pond) {
          this.cancelFishing();
          return;
        }
        const creature = this.rollPondCreature(pond);
        const rod = ITEMS[this.save.equippedRod] ?? ITEMS.rod_basic;
        f.hookedCreature = creature;
        f.phase = 'REELING';
        f.barHalfSize = 0.14 + (rod.reelAssist ?? 0);
        f.barPos = 0.45;
        f.barVel = 0;
        f.fishPos = 0.5;
        f.fishVel = 0;
        f.fishTarget = 0.45 + (Math.random() - 0.5) * 0.2;
        f.fishMoveTimer = 0.9;
        f.catchProgress = 0.28;
        f.tension = 0;
        soundEngine.castSplash();
        return;
      }
      if (f.timer <= 0) {
        soundEngine.lineSnap();
        this.showToast('The bite slipped off the hook...');
        this.cancelFishing();
      }
      return;
    }

    if (f.phase === 'REELING' && f.hookedCreature) {
      const rod = ITEMS[this.save.equippedRod] ?? ITEMS.rod_basic;
      const barHalfSize = 0.14 + (rod.reelAssist ?? 0);
      f.barHalfSize = barHalfSize;
      const diff = f.hookedCreature.fishingDifficulty;

      // Smooth fluid steering for the blue catch bar
      const lifting = input.jumpHeld || input.right;
      const barAccel = lifting ? 2.2 : -2.0;
      f.barVel += barAccel * dt;
      f.barVel *= Math.pow(0.035, dt);
      const nextBarPos = f.barPos + f.barVel * dt;
      if (nextBarPos <= barHalfSize) {
        f.barPos = barHalfSize;
        if (f.barVel < 0) f.barVel = 0;
      } else if (nextBarPos >= 1 - barHalfSize) {
        f.barPos = 1 - barHalfSize;
        if (f.barVel > 0) f.barVel = 0;
      } else {
        f.barPos = nextBarPos;
      }

      // Smooth, bounded spring-damped fish swim AI
      f.fishMoveTimer -= dt;
      if (f.fishMoveTimer <= 0) {
        f.fishMoveTimer = Math.max(0.75, 1.55 - diff * 0.16) + Math.random() * 0.6;
        const maxStep = 0.18 + diff * 0.055;
        const offset = (Math.random() * 2 - 1) * maxStep;
        const biasedTarget = f.fishPos + offset + (0.5 - f.fishPos) * 0.18;
        f.fishTarget = Math.max(0.1, Math.min(0.9, biasedTarget));
      }
      const toTarget = f.fishTarget - f.fishPos;
      const springStrength = 2.4 + diff * 0.45;
      f.fishVel += toTarget * springStrength * dt;
      f.fishVel *= Math.pow(0.12, dt);
      const maxFishSpeed = 0.34 + diff * 0.11;
      if (Math.abs(f.fishVel) > maxFishSpeed) {
        f.fishVel = Math.sign(f.fishVel) * maxFishSpeed;
      }
      const nextFishPos = f.fishPos + f.fishVel * dt;
      if (nextFishPos <= 0.08) {
        f.fishPos = 0.08;
        f.fishVel = Math.max(0, -f.fishVel * 0.35);
      } else if (nextFishPos >= 0.92) {
        f.fishPos = 0.92;
        f.fishVel = Math.min(0, -f.fishVel * 0.35);
      } else {
        f.fishPos = nextFishPos;
      }

      const insideBar = Math.abs(f.fishPos - f.barPos) <= barHalfSize;
      if (insideBar) {
        f.catchProgress = Math.min(1, f.catchProgress + (0.34 - diff * 0.025) * dt);
        f.tension = Math.max(0, f.tension - 0.35 * dt);
      } else {
        f.catchProgress = Math.max(0, f.catchProgress - 0.14 * dt);
        f.tension = Math.min(1, f.tension + (0.22 + diff * 0.045) * dt);
      }

      if (f.catchProgress >= 1) {
        soundEngine.catchSuccess();
        f.phase = 'CATCH_REVEAL';
        f.timer = f.hookedCreature.isBoss ? 999 : 1.05;
        return;
      }

      if (f.tension >= 1) {
        soundEngine.lineSnap();
        this.showToast(`${f.hookedCreature.name} snapped the line!`);
        this.cancelFishing();
      }
      return;
    }

    if (f.phase === 'CATCH_REVEAL' && f.hookedCreature) {
      if (!f.hookedCreature.isBoss) {
        f.timer -= dt;
        if (f.timer <= 0 || input.interactPressed || input.jumpPressed) {
          this.engageHookedCreature();
        }
      } else {
        if (input.interactPressed) {
          this.engageHookedCreature();
        }
      }
    }
  }

  private updatePlayer(dt: number, input: InputFrame) {
    const p = this.player;
    const solids = this.getRoomSolids();

    p.invulnTimer = Math.max(0, p.invulnTimer - dt);
    p.hitFlashTimer = Math.max(0, p.hitFlashTimer - dt);
    p.dashCooldownTimer = Math.max(0, p.dashCooldownTimer - dt);
    p.attackCooldownTimer = Math.max(0, p.attackCooldownTimer - dt);
    p.coyoteTimer = Math.max(0, p.coyoteTimer - dt);
    p.jumpBufferTimer = input.jumpPressed ? MC_CFG.jumpBuffer : Math.max(0, p.jumpBufferTimer - dt);

    // Interaction check [E]
    if (input.interactPressed && this.enemies.length === 0) {
      if (this.handleInteract()) return;
    }

    // Focus Heal [Q] (costs 33 essence)
    if (input.healPressed && this.save.essence >= 33 && this.save.hp < this.save.maxHp) {
      this.save.essence -= 33;
      this.save.hp = Math.min(this.save.maxHp, this.save.hp + 1);
      soundEngine.heal();
      this.spawnParticles(p.x, p.y, '#34d399', 16, 2.5);
      this.floatingTexts.push({ x: p.x, y: p.y + 0.7, text: '+1 HP', color: '#34d399', life: 0.75 });
    }

    // Cast Fishing Rod [F] (ONLY allowed inside designated pond fishing zones & when arena clear)
    if (input.fishPressed) {
      if (this.enemies.length > 0) {
        this.showToast('Defeat active abyssal creatures before casting again!');
      } else {
        const pond = this.getNearbyPond();
        if (!pond) {
          this.showToast('Fishing is only possible beside a designated pond.');
        } else {
          this.fishing.phase = 'CASTING';
          this.fishing.pondId = pond.id;
          this.fishing.pondName = pond.name;
          this.fishing.timer = 0.42;
          this.fishing.hookedCreature = null;
          p.vx = 0;
          this.setPlayerAnim('fishing');
          return;
        }
      }
    }

    // Dash [Shift / L]
    if (input.dashPressed && this.save.abilities.dash && p.dashCooldownTimer <= 0 && p.dashTimer <= 0) {
      p.dashTimer = MC_CFG.dashDuration;
      p.dashCooldownTimer = MC_CFG.dashCooldown;
      p.dashDir = p.flipX ? -1 : 1;
      p.invulnTimer = Math.max(p.invulnTimer, MC_CFG.dashDuration);
      soundEngine.dash();
      this.spawnParticles(p.x, p.y, '#38bdf8', 10, 3.0);
    }

    // Attack [Left Click / J / Enter]
    if (input.attackPressed && !p.isAttacking && p.attackCooldownTimer <= 0) {
      p.isAttacking = true;
      p.attackTimer = MC_CFG.attackDuration;
      p.attackCooldownTimer = MC_CFG.attackCooldown;
      p.attackEventFired = false;
      this.setPlayerAnim('attack');
      soundEngine.slash();
    }

    if (p.isAttacking) {
      p.attackTimer -= dt;
      if (!p.attackEventFired && p.animTime + dt >= 0.05) {
        p.attackEventFired = true;
        this.performPlayerMeleeHit();
      }
      if (p.attackTimer <= 0) {
        p.isAttacking = false;
      }
    }

    // Movement & Gravity
    if (p.dashTimer > 0) {
      p.dashTimer -= dt;
      p.vx = p.dashDir * MC_CFG.dashSpeed;
      p.vy = 0;
      if (Math.random() < 0.65) {
        this.dashAfterimages.push({ x: p.x, y: p.y, flipX: p.flipX, alpha: 0.55 });
      }
    } else {
      let gravMult = 1;
      if (p.vy < 0) gravMult = MC_CFG.fallGravMult;
      else if (p.vy > 0 && !input.jumpHeld) gravMult = MC_CFG.releaseGravMult;
      p.vy += GRAVITY * MC_CFG.gravityScale * gravMult * dt;

      // Wall slide cap
      if (!p.grounded && p.wallDir !== 0 && p.vy < MC_CFG.wallSlideMaxFall && this.save.abilities.wallCling) {
        p.vy = MC_CFG.wallSlideMaxFall;
      }

      const moveDir = (input.right ? 1 : 0) - (input.left ? 1 : 0);
      p.vx = moveDir * MC_CFG.moveSpeed;
      if (moveDir !== 0 && !p.isAttacking) {
        p.flipX = moveDir < 0;
      }

      // Jump resolution: Ground / Coyote -> Wall Jump -> Double Jump
      if (p.jumpBufferTimer > 0) {
        if (p.coyoteTimer > 0 || p.grounded) {
          p.vy = MC_CFG.jumpForce;
          p.grounded = false;
          p.coyoteTimer = 0;
          p.jumpBufferTimer = 0;
          soundEngine.jump();
          this.spawnParticles(p.x, p.y - 0.35, '#94a3b8', 6, 1.8);
        } else if (!p.grounded && p.wallDir !== 0 && this.save.abilities.wallCling) {
          p.vy = MC_CFG.wallJumpVy;
          p.vx = -p.wallDir * MC_CFG.wallJumpVx;
          p.flipX = p.wallDir === 1;
          p.jumpBufferTimer = 0;
          soundEngine.jump();
          this.spawnParticles(p.x + p.wallDir * 0.25, p.y, '#cbd5e1', 7, 2.0);
        } else if (this.save.abilities.doubleJump && p.airJumpsLeft > 0) {
          p.vy = MC_CFG.jumpForce * 0.92;
          p.airJumpsLeft -= 1;
          p.jumpBufferTimer = 0;
          soundEngine.doubleJump();
          this.spawnParticles(p.x, p.y - 0.2, '#38bdf8', 12, 2.6);
        }
      }
    }

    const moved = this.moveWithSolids(p.x, p.y, p.vx, p.vy, dt, solids, (cx, cy) =>
      this.getPlayerCollider(cx, cy),
    );
    p.x = moved.x;
    p.y = moved.y;
    p.vx = moved.vx;
    p.vy = moved.vy;
    p.grounded = moved.grounded;
    p.wallDir = moved.wallDir;

    if (p.grounded) {
      p.coyoteTimer = MC_CFG.coyoteTime;
      p.airJumpsLeft = this.save.abilities.doubleJump ? 1 : 0;
    }

    // Clamp inside room horizontal bounds unless exiting
    if (p.x < this.room.bounds.minX - 0.6) p.x = this.room.bounds.minX - 0.6;
    if (p.x > this.room.bounds.maxX + 0.6) p.x = this.room.bounds.maxX + 0.6;

    // Animation state
    if (!p.isAttacking) {
      if (p.vy > 0.05) this.setPlayerAnim('jump');
      else if (!p.grounded) this.setPlayerAnim('fall');
      else this.setPlayerAnim(Math.abs(p.vx) > 0.1 ? 'run' : 'idle');
    }
    p.animTime += dt;

    if (p.y < this.room.bounds.minY - 2.5) {
      this.save.hp = 0;
      p.alive = false;
      p.fellInAbyss = true;
      soundEngine.hitPlayer();
    }
  }

  private handleInteract(): boolean {
    const px = this.player.x;
    const py = this.player.y;

    for (const pickup of this.room.pickups) {
      if (this.save.collectedPickups.includes(pickup.id)) continue;
      if (Math.hypot(px - pickup.x, py - pickup.y) < 1.25) {
        this.save.collectedPickups.push(pickup.id);
        if (pickup.ability) {
          this.save.abilities[pickup.ability] = true;
        }
        if (pickup.shards) {
          this.save.shards += pickup.shards;
        }
        soundEngine.catchSuccess();
        this.spawnParticles(pickup.x, pickup.y, '#fbbf24', 24, 4.2);
        this.showToast(`Unlocked: ${pickup.title} — ${pickup.description}`, 4.2);
        this.writeSave();
        return true;
      }
    }

    for (const npc of this.room.npcs) {
      if (Math.hypot(px - npc.x, py - npc.y) < 1.65) {
        this.onOpenNpc?.(npc.id);
        return true;
      }
    }

    for (const shrine of this.room.saveShrines) {
      if (Math.hypot(px - shrine.x, py - shrine.y) < 1.35) {
        this.save.hp = this.save.maxHp;
        this.save.essence = Math.max(this.save.essence, 33);
        this.save.respawnRoomId = this.room.id;
        this.save.respawnX = shrine.x;
        this.save.respawnY = shrine.y + 0.68;
        this.writeSave();
        soundEngine.saveChime();
        this.spawnParticles(shrine.x, shrine.y + 0.5, '#38bdf8', 20, 3.0);
        this.showToast(`Rested & Saved at ${shrine.name}`);
        return true;
      }
    }

    for (const tablet of this.room.loreTablets) {
      if (Math.hypot(px - tablet.x, py - tablet.y) < 1.35) {
        this.onOpenLore?.(tablet.title, tablet.lines);
        return true;
      }
    }

    return false;
  }

  private performPlayerMeleeHit() {
    const hitbox = this.getPlayerAttackBox();
    const dmg = this.save.attackDamage;

    // Damage enemies
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.isBreaching) continue;
      if (aabbOverlap(hitbox, this.getEnemyCollider(e))) {
        e.hp = Math.max(0, e.hp - dmg);
        e.hitFlashTimer = 0.14;
        e.vx = (this.player.flipX ? -1 : 1) * (e.def.isBoss ? 1.6 : 4.2);
        soundEngine.hitEnemy();
        this.spawnParticles(e.x, e.y, '#fde047', 8, 3.2);
        this.floatingTexts.push({
          x: e.x,
          y: e.y + 0.65,
          text: `-${dmg}`,
          color: '#fde047',
          life: 0.65,
        });

        if (e.hp <= 0) {
          this.onEnemyDefeated(e);
          this.enemies.splice(i, 1);
        }
      }
    }

    // Damage breakable walls
    for (const wall of this.room.breakableWalls) {
      if (this.save.brokenWalls.includes(wall.id)) continue;
      if (aabbOverlap(hitbox, { x: wall.x, y: wall.y, w: wall.w, h: wall.h })) {
        wall.hp -= dmg;
        soundEngine.hitEnemy();
        this.spawnParticles(wall.x, wall.y, '#94a3b8', 10, 3.4);
        if (wall.hp <= 0) {
          this.save.brokenWalls.push(wall.id);
          this.shakeTimer = 0.25;
          this.shakeIntensity = 0.16;
          this.showToast('Shattered cracked ruin wall — secret passage opened!');
          this.writeSave();
        }
      }
    }
  }

  private onEnemyDefeated(e: ActiveEnemy) {
    this.save.shards += e.def.shardReward;
    this.save.essence = Math.min(99, this.save.essence + e.def.essenceReward);

    const entry = this.save.journal[e.def.id] ?? {
      caughtCount: 1,
      defeatedCount: 0,
      firstLocation: this.room.name,
    };
    entry.defeatedCount += 1;
    this.save.journal[e.def.id] = entry;

    this.spawnParticles(e.x, e.y, e.def.isBoss ? '#fbbf24' : '#38bdf8', 22, 4.5);
    this.floatingTexts.push({
      x: e.x,
      y: e.y + 0.9,
      text: `+${e.def.shardReward} Shards`,
      color: '#38bdf8',
      life: 0.95,
    });

    if (e.def.isBoss) {
      if (!this.save.defeatedBosses.includes(e.def.id)) {
        this.save.defeatedBosses.push(e.def.id);
        this.save.ownedItems.relic_shore_heart = 1;
      }
      soundEngine.catchSuccess();
      this.showToast('Victory! Claimed Heart of the Shore & 150 Tide Shards!', 4.8);
    }

    this.writeSave();
  }

  private damagePlayer(dmg: number, sourceX: number) {
    if (this.player.invulnTimer > 0 || !this.player.alive) return;
    this.save.hp = Math.max(0, this.save.hp - dmg);
    this.player.invulnTimer = 0.9;
    this.player.hitFlashTimer = 0.2;
    this.player.vy = 5.5;
    this.player.vx = (this.player.x >= sourceX ? 1 : -1) * 5.2;
    this.shakeTimer = 0.22;
    this.shakeIntensity = 0.14;
    soundEngine.hitPlayer();
    this.spawnParticles(this.player.x, this.player.y, '#fb7185', 12, 3.4);
    this.floatingTexts.push({
      x: this.player.x,
      y: this.player.y + 0.8,
      text: `-${dmg}`,
      color: '#fb7185',
      life: 0.75,
    });
    if (this.save.hp <= 0) {
      this.player.alive = false;
    }
  }

  private updateEnemies(dt: number) {
    const solids = this.getRoomSolids();

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      e.hitFlashTimer = Math.max(0, e.hitFlashTimer - dt);

      if (e.isBreaching) {
        e.breachElapsed += dt;
        const progress = Math.min(1, e.breachElapsed / 0.8);
        const arcHeight = 4 * 1.5 * progress * (1 - progress);
        e.x = e.breachStartX + (e.breachEndX - e.breachStartX) * progress;
        e.y = e.breachStartY + (e.breachEndY - e.breachStartY) * progress + arcHeight;
        e.animTime += dt;
        if (progress >= 1) {
          e.x = e.breachEndX;
          e.y = e.breachEndY;
          e.isBreaching = false;
          this.setEnemyAnim(e, 'idle');
        }
        continue;
      }

      e.attackCooldownTimer -= dt;
      e.vy += GRAVITY * dt;

      // Boss phase transition
      if (e.def.isBoss && e.phase === 1 && e.hp <= e.maxHp * 0.5) {
        e.phase = 2;
        soundEngine.bossRoar();
        this.shakeTimer = 0.4;
        this.shakeIntensity = 0.2;
        this.showToast('Krakor awakens the Abyssal Tide!', 2.5);
      }

      if (e.attackTimer > 0) {
        e.attackTimer -= dt;
        if (e.telegraphType === 'lunge') {
          e.vx = (e.flipX ? -1 : 1) * (e.def.isBoss ? 7.2 : 5.2);
        } else {
          e.vx = 0;
        }

        const eventTime = e.def.id === 'skirmisher' ? 0.25 : 0.28;
        if (!e.attackEventFired && e.animTime + dt >= eventTime) {
          e.attackEventFired = true;
          this.executeEnemyAttack(e);
        }
        if (e.attackTimer <= 0) {
          e.telegraphType = 'none';
          this.setEnemyAnim(e, 'idle');
        }
      } else {
        const diffX = this.player.x - e.x;
        const distX = Math.abs(diffX);

        if (distX > e.def.detectionRange) {
          e.vx = 0;
          this.setEnemyAnim(e, 'idle');
        } else {
          if (distX > 0.05) e.flipX = diffX < 0;

          // Boss special geyser attack in Phase 2
          if (e.def.isBoss && e.phase === 2) {
            e.specialTimer -= dt;
            if (e.specialTimer <= 0) {
              e.specialTimer = 3.4;
              this.geysers.push({
                x: this.player.x,
                y: -2.02,
                warnTimer: 0.75,
                activeTimer: 0.45,
                hitPlayer: false,
              });
              this.geysers.push({
                x: this.player.x + (Math.random() > 0.5 ? 2.4 : -2.4),
                y: -2.02,
                warnTimer: 0.75,
                activeTimer: 0.45,
                hitPlayer: false,
              });
            }
          }

          if (distX <= e.def.attackRange) {
            e.vx = 0;
            if (e.attackCooldownTimer <= 0) {
              e.attackTimer = e.def.attackDuration;
              e.attackCooldownTimer =
                e.def.isBoss && e.phase === 2
                  ? e.def.attackCooldown * 0.72
                  : e.def.attackCooldown;
              e.attackEventFired = false;
              e.telegraphType =
                e.def.id === 'mire_eel' || (e.def.isBoss && Math.random() < 0.45)
                  ? 'lunge'
                  : 'slam';
              this.setEnemyAnim(e, 'attack');
            } else {
              this.setEnemyAnim(e, 'idle');
            }
          } else {
            e.vx = Math.sign(diffX) * e.def.moveSpeed * (e.def.isBoss && e.phase === 2 ? 1.25 : 1);
            this.setEnemyAnim(e, 'walk');
          }
        }
      }

      const moved = this.moveWithSolids(e.x, e.y, e.vx, e.vy, dt, solids, (cx, cy) =>
        this.getEnemyCollider(e, cx, cy),
      );
      e.x = moved.x;
      e.y = moved.y;
      e.vx = moved.vx;
      e.vy = moved.vy;
      e.grounded = moved.grounded;
      e.animTime += dt;

      // Contact damage check
      if (aabbOverlap(this.getPlayerCollider(), this.getEnemyCollider(e))) {
        this.damagePlayer(1, e.x);
      }
    }
  }

  private executeEnemyAttack(e: ActiveEnemy) {
    if (e.def.id === 'dartfin') {
      const dir = e.flipX ? -1 : 1;
      this.projectiles.push({
        x: e.x + dir * 0.45,
        y: e.y + 0.05,
        vx: dir * 6.8,
        vy: 0.6,
        radius: 0.18,
        damage: e.def.damage,
        color: '#38bdf8',
        life: 2.2,
        fromEnemy: true,
      });
      return;
    }

    if (aabbOverlap(this.getEnemyAttackBox(e), this.getPlayerCollider())) {
      this.damagePlayer(e.def.damage, e.x);
    }
    if (e.def.isBoss) {
      this.shakeTimer = 0.2;
      this.shakeIntensity = 0.12;
      this.spawnParticles(e.x + (e.flipX ? -1.1 : 1.1), e.y - 0.4, '#fb7185', 14, 3.6);
    }
  }

  private updateProjectilesAndGeysers(dt: number) {
    const pBox = this.getPlayerCollider();
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.x += pr.vx * dt;
      pr.y += pr.vy * dt;
      pr.life -= dt;
      if (pr.fromEnemy) {
        if (
          aabbOverlap(pBox, {
            x: pr.x,
            y: pr.y,
            w: pr.radius * 2,
            h: pr.radius * 2,
          })
        ) {
          this.damagePlayer(pr.damage, pr.x);
          this.projectiles.splice(i, 1);
          continue;
        }
      }
      if (pr.life <= 0) this.projectiles.splice(i, 1);
    }

    for (let i = this.geysers.length - 1; i >= 0; i--) {
      const g = this.geysers[i];
      if (g.warnTimer > 0) {
        g.warnTimer -= dt;
      } else {
        g.activeTimer -= dt;
        if (
          !g.hitPlayer &&
          aabbOverlap(pBox, { x: g.x, y: g.y + 1.5, w: 0.9, h: 3.0 })
        ) {
          g.hitPlayer = true;
          this.damagePlayer(2, g.x);
        }
        if (g.activeTimer <= 0) {
          this.geysers.splice(i, 1);
        }
      }
    }
  }

  private checkExits() {
    if (this.enemies.length > 0) return; // Arena locked while fished creature is active!
    const pBox = this.getPlayerCollider();
    for (const exit of this.room.exits) {
      if (aabbOverlap(pBox, { x: exit.x, y: exit.y, w: exit.w, h: exit.h })) {
        this.transitionToRoom(exit.targetRoom, exit.spawnX, exit.spawnY);
        break;
      }
    }
  }

  private updateCamera(dt: number) {
    const b = this.room.bounds;
    const halfH = CAMERA_ORTHO_SIZE;
    const halfW = CAMERA_ORTHO_SIZE * 1.777;
    const targetX = Math.max(
      b.minX + halfW * 0.45,
      Math.min(b.maxX - halfW * 0.45, this.player.x),
    );
    const targetY = Math.max(
      b.minY + halfH * 0.5,
      Math.min(b.maxY - halfH * 0.5, this.player.y + 0.65),
    );
    const lerp = 1 - Math.exp(-8 * dt);
    this.camX += (targetX - this.camX) * lerp;
    this.camY += (targetY - this.camY) * lerp;
  }

  getHudSnapshot(): HudSnapshot {
    const rod = ITEMS[this.save.equippedRod] ?? ITEMS.rod_basic;
    const bait = ITEMS[this.save.equippedBait] ?? ITEMS.bait_none;
    const boss = this.enemies.find((e) => e.def.isBoss);
    return {
      roomId: this.room.id,
      roomName: this.room.name,
      regionName: this.room.regionName,
      hp: this.save.hp,
      maxHp: this.save.maxHp,
      essence: this.save.essence,
      shards: this.save.shards,
      equippedRodName: rod.name,
      equippedBaitName: bait.name,
      abilities: { ...this.save.abilities },
      activeEnemies: this.enemies.length,
      bossActive: boss
        ? { name: boss.def.name, hp: boss.hp, maxHp: boss.maxHp, phase: boss.phase }
        : null,
      fishing: { ...this.fishing },
      nearbyPrompt: this.getNearbyPrompt(),
      toastMessage: this.toastMessage,
      alive: this.player.alive,
      fellInAbyss: this.player.fellInAbyss,
      arenaLocked: this.enemies.length > 0,
    };
  }

  render(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    atlas: SpriteAtlas,
    showHitboxes: boolean,
  ) {
    const pxPerUnit = height / (CAMERA_ORTHO_SIZE * 2);
    const shakeX =
      this.shakeTimer > 0 ? (Math.random() - 0.5) * this.shakeIntensity : 0;
    const shakeY =
      this.shakeTimer > 0 ? (Math.random() - 0.5) * this.shakeIntensity : 0;

    const toSX = (wx: number) => width * 0.5 + (wx - (this.camX + shakeX)) * pxPerUnit;
    const toSY = (wy: number) => height * 0.5 - (wy - (this.camY + shakeY)) * pxPerUnit;

    // 1. Background sky/cavern gradient
    const bg = ctx.createLinearGradient(0, 0, 0, height);
    bg.addColorStop(0, this.room.ambientColorTop);
    bg.addColorStop(1, this.room.ambientColorBottom);
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    // Parallax cave pillars & glowing abyssal spores
    ctx.fillStyle = 'rgba(6, 12, 24, 0.42)';
    for (let i = -4; i <= 6; i++) {
      const px = toSX(i * 5.2 - this.camX * 0.35);
      ctx.fillRect(px - 0.45 * pxPerUnit, 0, 0.9 * pxPerUnit, height);
    }
    for (let i = 0; i < 18; i++) {
      const sx = ((i * 193 + this.worldTime * 12) % (width + 80)) - 40;
      const sy = ((i * 117 + Math.sin(this.worldTime + i) * 28) % height + height) % height;
      ctx.fillStyle = 'rgba(125, 211, 252, 0.14)';
      ctx.fillRect(sx, sy, 3, 3);
    }

    ctx.imageSmoothingEnabled = false;

    // 2. Ponds (behind platforms)
    this.renderPonds(ctx, atlas, toSX, toSY, pxPerUnit);

    // 3. Background decorations & exit doorways
    this.renderDecorations(ctx, toSX, toSY, pxPerUnit);
    this.renderExits(ctx, toSX, toSY, pxPerUnit);

    // 4. Platforms & Breakable Walls
    this.renderPlatforms(ctx, atlas, toSX, toSY, pxPerUnit);

    // 5. Shrines, Pickups, Tablets, NPCs
    this.renderInteractables(ctx, toSX, toSY, pxPerUnit);

    // 6. Arena Lock Barriers (when fished enemy active)
    if (this.enemies.length > 0) {
      for (const exit of this.room.exits) {
        const ex = toSX(exit.x);
        const ey = toSY(exit.y);
        ctx.fillStyle = 'rgba(244, 63, 94, 0.32)';
        ctx.fillRect(ex - 4, ey - exit.h * 0.5 * pxPerUnit, 8, exit.h * pxPerUnit);
      }
    }

    // 7. Dash afterimages
    for (const img of this.dashAfterimages) {
      const clip = MC_ANIMS.jump;
      const sheet = atlas[clip.sheet];
      if (!sheet) continue;
      const slice = sampleClipFrame(clip, 0.15);
      const dw = (slice.w / PIXELS_PER_UNIT) * MC_CFG.scaleX * pxPerUnit;
      const dh = (slice.h / PIXELS_PER_UNIT) * MC_CFG.scaleY * pxPerUnit;
      ctx.save();
      ctx.globalAlpha = img.alpha * 0.65;
      ctx.translate(toSX(img.x), toSY(img.y));
      if (img.flipX) ctx.scale(-1, 1);
      ctx.drawImage(sheet, slice.x, slice.y, slice.w, slice.h, -dw * 0.5, -dh * 0.5, dw, dh);
      ctx.restore();
    }

    // 8. Active Fished Enemies
    this.renderEnemies(ctx, atlas, toSX, toSY, pxPerUnit);

    // 9. Protagonist (MC)
    if (this.player.alive) {
      this.renderPlayer(ctx, atlas, toSX, toSY, pxPerUnit);
    }

    // 10. Projectiles, Geysers, Particles & Floating Texts
    for (const pr of this.projectiles) {
      ctx.fillStyle = pr.color;
      ctx.beginPath();
      ctx.arc(toSX(pr.x), toSY(pr.y), pr.radius * pxPerUnit, 0, Math.PI * 2);
      ctx.fill();
    }

    for (const g of this.geysers) {
      const gx = toSX(g.x);
      const gy = toSY(g.y);
      if (g.warnTimer > 0) {
        ctx.fillStyle = 'rgba(251, 113, 133, 0.45)';
        ctx.fillRect(gx - 0.45 * pxPerUnit, gy - 8, 0.9 * pxPerUnit, 8);
      } else {
        ctx.fillStyle = 'rgba(244, 63, 94, 0.72)';
        ctx.fillRect(gx - 0.42 * pxPerUnit, gy - 3.0 * pxPerUnit, 0.84 * pxPerUnit, 3.0 * pxPerUnit);
      }
    }

    for (const pt of this.particles) {
      ctx.globalAlpha = Math.max(0, pt.life / pt.maxLife);
      ctx.fillStyle = pt.color;
      ctx.fillRect(toSX(pt.x), toSY(pt.y), pt.size, pt.size);
    }
    ctx.globalAlpha = 1;

    for (const ft of this.floatingTexts) {
      ctx.save();
      ctx.globalAlpha = Math.min(1, ft.life * 1.8);
      ctx.font = `bold ${Math.round(pxPerUnit * 0.22)}px 'JetBrains Mono', monospace`;
      ctx.textAlign = 'center';
      ctx.fillStyle = '#020617';
      ctx.fillText(ft.text, toSX(ft.x) + 1.5, toSY(ft.y) + 1.5);
      ctx.fillStyle = ft.color;
      ctx.fillText(ft.text, toSX(ft.x), toSY(ft.y));
      ctx.restore();
    }

    if (showHitboxes) {
      const drawBox = (box: AABB, color: string) => {
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.5;
        ctx.strokeRect(
          toSX(box.x - box.w * 0.5),
          toSY(box.y + box.h * 0.5),
          box.w * pxPerUnit,
          box.h * pxPerUnit,
        );
      };
      for (const s of this.getRoomSolids()) drawBox(s, '#22c55e');
      drawBox(this.getPlayerCollider(), '#38bdf8');
      if (this.player.isAttacking) drawBox(this.getPlayerAttackBox(), '#facc15');
      for (const e of this.enemies) drawBox(this.getEnemyCollider(e), '#fb7185');
    }

    if (this.transitionAlpha > 0) {
      ctx.fillStyle = `rgba(4, 8, 16, ${this.transitionAlpha})`;
      ctx.fillRect(0, 0, width, height);
    }
  }

  private renderPonds(
    ctx: CanvasRenderingContext2D,
    atlas: SpriteAtlas,
    toSX: (wx: number) => number,
    toSY: (wy: number) => number,
    pxPerUnit: number,
  ) {
    for (const pond of this.room.ponds) {
      if (pond.visualType === 'cave_pond_asset') {
        const img = atlas[WORLD_SPRITES.cavePond.sheet];
        if (img) {
          const slice = sampleClipFrame(WORLD_SPRITES.cavePond, this.worldTime);
          const sx = toSX(pond.x);
          const sy = toSY(pond.y);
          const dw = pond.w * pxPerUnit;
          const dh = pond.h * pxPerUnit;
          ctx.drawImage(img, slice.x, slice.y, slice.w, slice.h, sx - dw * 0.5, sy - dh * 0.5, dw, dh);
        }
      } else {
        // Stylized Deepwell or Maw Whirlpool pond matching the pixel-art cave pond palette
        const sx = toSX(pond.x);
        const topY = toSY(pond.y);
        const dw = pond.w * pxPerUnit;
        const dh = pond.h * pxPerUnit;
        const grad = ctx.createLinearGradient(0, topY, 0, topY + dh);
        if (pond.visualType === 'maw_whirlpool') {
          grad.addColorStop(0, '#581c4c');
          grad.addColorStop(1, '#12071a');
        } else {
          grad.addColorStop(0, '#0e4a5e');
          grad.addColorStop(1, '#061826');
        }
        ctx.fillStyle = grad;
        ctx.fillRect(sx - dw * 0.5, topY, dw, dh);

        // Animated ripples
        ctx.fillStyle =
          pond.visualType === 'maw_whirlpool'
            ? 'rgba(251, 113, 133, 0.55)'
            : 'rgba(103, 232, 249, 0.5)';
        for (let r = 0; r < 4; r++) {
          const rx = sx - dw * 0.35 + ((r * 2.1 + this.worldTime * 0.6) % (dw * 0.7));
          ctx.fillRect(rx, topY + 2, 28, 3);
        }
      }

      // Subtle glow over fishing zone
      const pulse = 0.35 + Math.sin(this.worldTime * 3) * 0.15;
      ctx.fillStyle =
        pond.visualType === 'maw_whirlpool'
          ? `rgba(244, 63, 94, ${pulse * 0.25})`
          : `rgba(56, 189, 248, ${pulse * 0.22})`;
      ctx.fillRect(
        toSX(pond.zoneX - pond.zoneW * 0.5),
        toSY(pond.y + 0.12),
        pond.zoneW * pxPerUnit,
        0.12 * pxPerUnit,
      );
    }
  }

  private renderPlatforms(
    ctx: CanvasRenderingContext2D,
    atlas: SpriteAtlas,
    toSX: (wx: number) => number,
    toSY: (wy: number) => number,
    pxPerUnit: number,
  ) {
    const groundImg = atlas[WORLD_SPRITES.platform.sheet];
    for (const plat of this.room.platforms) {
      const sx = toSX(plat.x);
      const sy = toSY(plat.y);
      const dw = plat.w * pxPerUnit;
      const dh = plat.h * pxPerUnit;

      if (groundImg && plat.style === 'platform_long') {
        const s = WORLD_SPRITES.platform.slice;
        ctx.drawImage(groundImg, s.x, s.y, s.w, s.h, sx - dw * 0.5, sy - dh * 0.5, dw, dh);
      } else if (groundImg) {
        const s = WORLD_SPRITES.groundTile.slice;
        ctx.drawImage(groundImg, s.x, s.y, s.w, s.h, sx - dw * 0.5, sy - dh * 0.5, dw, dh);
      } else {
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(sx - dw * 0.5, sy - dh * 0.5, dw, dh);
      }
    }

    // Breakable cracked walls
    for (const w of this.room.breakableWalls) {
      if (this.save.brokenWalls.includes(w.id)) continue;
      const sx = toSX(w.x);
      const sy = toSY(w.y);
      const dw = w.w * pxPerUnit;
      const dh = w.h * pxPerUnit;
      ctx.fillStyle = '#334155';
      ctx.fillRect(sx - dw * 0.5, sy - dh * 0.5, dw, dh);
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.strokeRect(sx - dw * 0.5, sy - dh * 0.5, dw, dh);
      // Cracks indicator
      ctx.strokeStyle = '#fbbf24';
      ctx.beginPath();
      ctx.moveTo(sx - dw * 0.25, sy - dh * 0.3);
      ctx.lineTo(sx + dw * 0.15, sy);
      ctx.lineTo(sx - dw * 0.2, sy + dh * 0.28);
      ctx.stroke();
    }
  }

  private renderDecorations(
    ctx: CanvasRenderingContext2D,
    toSX: (wx: number) => number,
    toSY: (wy: number) => number,
    pxPerUnit: number,
  ) {
    for (const d of this.room.decorations) {
      const sx = toSX(d.x);
      const sy = toSY(d.y);
      const sc = (d.scale ?? 1) * pxPerUnit;
      if (d.type === 'arch') {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.fillRect(sx - 0.5 * sc, sy - 2.3 * sc, 1.0 * sc, 2.3 * sc);
        ctx.fillStyle = 'rgba(56, 189, 248, 0.12)';
        ctx.fillRect(sx - 0.3 * sc, sy - 2.0 * sc, 0.6 * sc, 2.0 * sc);
      } else if (d.type === 'pillar') {
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(sx - 0.25 * sc, sy - 2.2 * sc, 0.5 * sc, 2.2 * sc);
        ctx.fillStyle = '#334155';
        ctx.fillRect(sx - 0.35 * sc, sy - 2.3 * sc, 0.7 * sc, 0.2 * sc);
      } else if (d.type === 'mushroom') {
        ctx.fillStyle = '#334155';
        ctx.fillRect(sx - 0.06 * sc, sy - 0.35 * sc, 0.12 * sc, 0.35 * sc);
        ctx.fillStyle = '#2dd4bf';
        ctx.beginPath();
        ctx.arc(sx, sy - 0.35 * sc, 0.24 * sc, Math.PI, 0);
        ctx.fill();
      } else if (d.type === 'crystal') {
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.moveTo(sx, sy - 0.7 * sc);
        ctx.lineTo(sx + 0.18 * sc, sy);
        ctx.lineTo(sx - 0.18 * sc, sy);
        ctx.closePath();
        ctx.fill();
      } else if (d.type === 'lamp') {
        ctx.fillStyle = '#475569';
        ctx.fillRect(sx - 0.04 * sc, sy - 1.3 * sc, 0.08 * sc, 1.3 * sc);
        ctx.fillStyle = 'rgba(186, 230, 253, 0.85)';
        ctx.fillRect(sx - 0.12 * sc, sy - 1.45 * sc, 0.24 * sc, 0.22 * sc);
      }
    }
  }

  private renderExits(
    ctx: CanvasRenderingContext2D,
    toSX: (wx: number) => number,
    toSY: (wy: number) => number,
    pxPerUnit: number,
  ) {
    if (this.enemies.length > 0) return;

    for (const exit of this.room.exits) {
      const ex = toSX(exit.x);
      const ey = toSY(exit.y);
      const dist = Math.hypot(this.player.x - exit.x, this.player.y - exit.y);
      const pulse = 0.22 + Math.sin(this.worldTime * 2.6) * 0.08;
      const proxBoost = dist < 4.5 ? Math.max(0, 1 - dist / 4.5) : 0;

      // Subtle glowing doorway mist
      const glowRadius = Math.max(exit.w, exit.h) * 0.65 * pxPerUnit;
      const grad = ctx.createRadialGradient(ex, ey, 2, ex, ey, glowRadius);
      grad.addColorStop(0, `rgba(125, 211, 252, ${(pulse + proxBoost * 0.25).toFixed(3)})`);
      grad.addColorStop(1, 'rgba(125, 211, 252, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(ex, ey, glowRadius, 0, Math.PI * 2);
      ctx.fill();

      // Destination directional marker when within view/proximity
      const arrow =
        exit.direction === 'left'
          ? '←'
          : exit.direction === 'right'
          ? '→'
          : exit.direction === 'up'
          ? '↑'
          : '↓';
      const labelY =
        exit.direction === 'up'
          ? ey + (exit.h * 0.5 + 0.35) * pxPerUnit
          : ey - (exit.h * 0.5 + 0.28) * pxPerUnit;
      const alpha = 0.45 + proxBoost * 0.5;

      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.font = `600 ${Math.max(11, Math.round(pxPerUnit * 0.19))}px 'Inter', sans-serif`;
      ctx.textAlign = 'center';
      const text = `${arrow} ${exit.label}`;
      ctx.fillStyle = '#020617';
      ctx.fillText(text, ex + 1, labelY + 1);
      ctx.fillStyle = '#bae6fd';
      ctx.fillText(text, ex, labelY);
      ctx.restore();
    }
  }

  private renderInteractables(
    ctx: CanvasRenderingContext2D,
    toSX: (wx: number) => number,
    toSY: (wy: number) => number,
    pxPerUnit: number,
  ) {
    // Save Lanterns
    for (const s of this.room.saveShrines) {
      const sx = toSX(s.x);
      const sy = toSY(s.y);
      const glow = 0.3 + Math.sin(this.worldTime * 3.2) * 0.1;
      ctx.fillStyle = `rgba(56, 189, 248, ${glow})`;
      ctx.beginPath();
      ctx.arc(sx, sy - 0.9 * pxPerUnit, 0.65 * pxPerUnit, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#334155';
      ctx.fillRect(sx - 0.18 * pxPerUnit, sy - 0.2 * pxPerUnit, 0.36 * pxPerUnit, 0.2 * pxPerUnit);
      ctx.fillStyle = '#475569';
      ctx.fillRect(sx - 0.06 * pxPerUnit, sy - 0.9 * pxPerUnit, 0.12 * pxPerUnit, 0.7 * pxPerUnit);
      ctx.fillStyle = '#e0f2fe';
      ctx.fillRect(sx - 0.14 * pxPerUnit, sy - 1.12 * pxPerUnit, 0.28 * pxPerUnit, 0.28 * pxPerUnit);
    }

    // Lore Tablets
    for (const t of this.room.loreTablets) {
      const sx = toSX(t.x);
      const sy = toSY(t.y);
      ctx.fillStyle = '#334155';
      ctx.fillRect(sx - 0.32 * pxPerUnit, sy - 0.9 * pxPerUnit, 0.64 * pxPerUnit, 0.9 * pxPerUnit);
      ctx.fillStyle = '#7dd3fc';
      ctx.fillRect(sx - 0.18 * pxPerUnit, sy - 0.7 * pxPerUnit, 0.36 * pxPerUnit, 0.06 * pxPerUnit);
      ctx.fillRect(sx - 0.18 * pxPerUnit, sy - 0.52 * pxPerUnit, 0.26 * pxPerUnit, 0.06 * pxPerUnit);
    }

    // Relic Pickups
    for (const pk of this.room.pickups) {
      if (this.save.collectedPickups.includes(pk.id)) continue;
      const sx = toSX(pk.x);
      const sy = toSY(pk.y + Math.sin(this.worldTime * 3.5) * 0.12);
      ctx.fillStyle = 'rgba(251, 191, 36, 0.28)';
      ctx.beginPath();
      ctx.arc(sx, sy, 0.48 * pxPerUnit, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.moveTo(sx, sy - 0.28 * pxPerUnit);
      ctx.lineTo(sx + 0.22 * pxPerUnit, sy);
      ctx.lineTo(sx, sy + 0.28 * pxPerUnit);
      ctx.lineTo(sx - 0.22 * pxPerUnit, sy);
      ctx.closePath();
      ctx.fill();
    }

    // NPCs (Old Mara)
    for (const npc of this.room.npcs) {
      const sx = toSX(npc.x);
      const sy = toSY(npc.y);
      // Hooded lantern-elder silhouette matching MC pixel style
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(sx - 0.28 * pxPerUnit, sy - 1.05 * pxPerUnit, 0.56 * pxPerUnit, 1.05 * pxPerUnit);
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.arc(sx, sy - 1.05 * pxPerUnit, 0.28 * pxPerUnit, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fde68a';
      ctx.fillRect(sx - 0.12 * pxPerUnit, sy - 1.08 * pxPerUnit, 0.07 * pxPerUnit, 0.07 * pxPerUnit);
      ctx.fillRect(sx + 0.04 * pxPerUnit, sy - 1.08 * pxPerUnit, 0.07 * pxPerUnit, 0.07 * pxPerUnit);
    }
  }

  private renderPlayer(
    ctx: CanvasRenderingContext2D,
    atlas: SpriteAtlas,
    toSX: (wx: number) => number,
    toSY: (wy: number) => number,
    pxPerUnit: number,
  ) {
    const p = this.player;
    const clip = MC_ANIMS[p.anim];
    const img = atlas[clip.sheet];
    const sx = toSX(p.x);
    const sy = toSY(p.y);

    if (img) {
      const slice = sampleClipFrame(clip, p.animTime);
      const dw = (slice.w / PIXELS_PER_UNIT) * MC_CFG.scaleX * pxPerUnit;
      const dh = (slice.h / PIXELS_PER_UNIT) * MC_CFG.scaleY * pxPerUnit;
      ctx.save();
      ctx.translate(sx, sy);
      if (p.flipX) ctx.scale(-1, 1);
      if (p.hitFlashTimer > 0) ctx.filter = 'brightness(2.2) sepia(1) hue-rotate(-30deg)';
      else if (p.invulnTimer > 0 && Math.floor(this.worldTime * 16) % 2 === 0) ctx.globalAlpha = 0.55;
      ctx.drawImage(img, slice.x, slice.y, slice.w, slice.h, -dw * 0.5, -dh * 0.5, dw, dh);
      ctx.restore();
    }

    // Draw glowing fishing line & bobber when casting / waiting / reeling!
    if (this.fishing.phase !== 'IDLE') {
      const dir = p.flipX ? -1 : 1;
      const rodTipX = sx + dir * 0.55 * pxPerUnit;
      const rodTipY = sy - 0.12 * pxPerUnit;
      const pond = this.room.ponds.find((pd) => pd.id === this.fishing.pondId);
      const bobX = toSX(pond ? pond.x : p.x + dir * 2.1);
      const bobY = toSY((pond ? pond.y : -2.02) + (this.fishing.phase === 'BITE_WINDOW' ? -0.14 : 0));

      ctx.strokeStyle = '#bae6fd';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(rodTipX, rodTipY);
      ctx.quadraticCurveTo((rodTipX + bobX) * 0.5, Math.min(rodTipY, bobY) - 18, bobX, bobY);
      ctx.stroke();

      ctx.fillStyle = this.fishing.phase === 'BITE_WINDOW' ? '#fb7185' : '#38bdf8';
      ctx.beginPath();
      ctx.arc(bobX, bobY, 5, 0, Math.PI * 2);
      ctx.fill();

      if (this.fishing.phase === 'BITE_WINDOW') {
        ctx.font = `bold ${Math.round(pxPerUnit * 0.42)}px 'Cinzel', serif`;
        ctx.textAlign = 'center';
        ctx.fillStyle = '#fbbf24';
        ctx.fillText('! HOOK NOW !', sx, sy - 0.95 * pxPerUnit);
      }
    }
  }

  private renderEnemies(
    ctx: CanvasRenderingContext2D,
    atlas: SpriteAtlas,
    toSX: (wx: number) => number,
    toSY: (wy: number) => number,
    pxPerUnit: number,
  ) {
    for (const e of this.enemies) {
      const sx = toSX(e.x);
      const sy = toSY(e.y);

      if (e.def.id === 'skirmisher') {
        const clip = ENEMY_ANIMS[e.anim];
        const img = atlas[clip.sheet];
        if (img) {
          const slice = sampleClipFrame(clip, e.animTime);
          const dw = (slice.w / PIXELS_PER_UNIT) * pxPerUnit;
          const dh = (slice.h / PIXELS_PER_UNIT) * pxPerUnit;
          ctx.save();
          ctx.translate(sx, sy);
          if (e.flipX) ctx.scale(-1, 1);
          if (e.hitFlashTimer > 0) ctx.filter = 'brightness(2.2) saturate(0.2)';
          ctx.drawImage(img, slice.x, slice.y, slice.w, slice.h, -dw * 0.5, -dh * 0.5, dw, dh);
          ctx.restore();
        }
      } else {
        // Stylized pixel-art sprites matching the dark outline aesthetic for additional abyssal species
        ctx.save();
        ctx.translate(sx, sy);
        if (e.flipX) ctx.scale(-1, 1);
        if (e.hitFlashTimer > 0) ctx.filter = 'brightness(2.2)';
        this.drawCustomCreatureSprite(ctx, e, pxPerUnit);
        ctx.restore();
      }

      if (!e.isBreaching && !e.def.isBoss) {
        const bw = 0.9 * pxPerUnit;
        ctx.fillStyle = 'rgba(2, 6, 23, 0.85)';
        ctx.fillRect(sx - bw * 0.5 - 1, sy - 0.72 * pxPerUnit - 1, bw + 2, 7);
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(sx - bw * 0.5, sy - 0.72 * pxPerUnit, bw * (e.hp / e.maxHp), 5);
      }
    }
  }

  private drawCustomCreatureSprite(
    ctx: CanvasRenderingContext2D,
    e: ActiveEnemy,
    pxPerUnit: number,
  ) {
    const bob = Math.sin(this.worldTime * 8) * 2;
    const u = pxPerUnit;

    if (e.def.id === 'dartfin') {
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.ellipse(0, bob, 0.42 * u, 0.25 * u, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#0d9488';
      ctx.beginPath();
      ctx.ellipse(0, bob, 0.36 * u, 0.2 * u, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#67e8f9';
      ctx.fillRect(0.24 * u, -0.24 * u + bob, 0.1 * u, 0.1 * u);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0.14 * u, -0.05 * u + bob, 0.08 * u, 0.08 * u);
    } else if (e.def.id === 'shellback') {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-0.5 * u, -0.5 * u, 1.0 * u, 0.95 * u);
      ctx.fillStyle = '#334155';
      ctx.fillRect(-0.44 * u, -0.44 * u, 0.88 * u, 0.78 * u);
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(0.18 * u, -0.2 * u, 0.12 * u, 0.12 * u);
    } else if (e.def.id === 'mire_eel') {
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(-0.55 * u, -0.3 * u + bob, 1.1 * u, 0.6 * u);
      ctx.fillStyle = '#a855f7';
      ctx.fillRect(-0.42 * u, -0.42 * u + bob, 0.2 * u, 0.16 * u);
      ctx.fillRect(0, -0.45 * u + bob, 0.2 * u, 0.18 * u);
      ctx.fillStyle = '#f43f5e';
      ctx.fillRect(0.26 * u, -0.1 * u + bob, 0.12 * u, 0.12 * u);
    } else if (e.def.id === 'krakor_boss') {
      const sc = 1.55 * u;
      // Armored Leviathan Sentinel with rusted halberd & phase 2 abyssal aura
      if (e.phase === 2) {
        ctx.fillStyle = 'rgba(244, 63, 94, 0.25)';
        ctx.beginPath();
        ctx.arc(0, 0, 0.72 * sc, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = '#090d16';
      ctx.fillRect(-0.42 * sc, -0.55 * sc, 0.84 * sc, 1.1 * sc);
      ctx.fillStyle = e.phase === 2 ? '#881337' : '#1e3a5f';
      ctx.fillRect(-0.36 * sc, -0.48 * sc, 0.72 * sc, 0.95 * sc);
      // Crown horns
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(-0.26 * sc, -0.68 * sc, 0.12 * sc, 0.22 * sc);
      ctx.fillRect(0.14 * sc, -0.68 * sc, 0.12 * sc, 0.22 * sc);
      // Glowing eyes
      ctx.fillStyle = e.phase === 2 ? '#fb7185' : '#38bdf8';
      ctx.fillRect(0.08 * sc, -0.32 * sc, 0.12 * sc, 0.08 * sc);
      // Halberd
      ctx.fillStyle = '#78350f';
      ctx.fillRect(0.32 * sc, -0.55 * sc, 0.1 * sc, 1.05 * sc);
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(0.28 * sc, -0.75 * sc, 0.26 * sc, 0.28 * sc);
    }
  }
}
