import type {
  CreatureDefinition,
  EnemyKind,
  EquipmentItem,
  Rarity,
  RoomConfig,
  RoomId,
} from './types';

export const RARITY_META: Record<
  Rarity,
  { color: string; bg: string; border: string; label: string }
> = {
  Common: {
    color: '#cbd5e1',
    bg: 'rgba(51, 65, 85, 0.55)',
    border: '#64748b',
    label: 'Common',
  },
  Uncommon: {
    color: '#34d399',
    bg: 'rgba(6, 78, 59, 0.55)',
    border: '#10b981',
    label: 'Uncommon',
  },
  Rare: {
    color: '#38bdf8',
    bg: 'rgba(12, 74, 110, 0.55)',
    border: '#0ea5e9',
    label: 'Rare',
  },
  Epic: {
    color: '#c084fc',
    bg: 'rgba(88, 28, 135, 0.55)',
    border: '#a855f7',
    label: 'Epic',
  },
  Legendary: {
    color: '#fbbf24',
    bg: 'rgba(120, 53, 15, 0.6)',
    border: '#f59e0b',
    label: 'Legendary',
  },
  Abyssal: {
    color: '#fb7185',
    bg: 'rgba(136, 19, 55, 0.6)',
    border: '#f43f5e',
    label: 'Abyssal',
  },
};

export const CREATURES: Record<EnemyKind, CreatureDefinition> = {
  skirmisher: {
    id: 'skirmisher',
    name: 'Trench Skirmisher',
    category: 'Aquatic Predator',
    rarity: 'Common',
    maxHp: 5,
    damage: 1,
    moveSpeed: 2.2,
    detectionRange: 8.5,
    attackRange: 1.4,
    attackCooldown: 1.45,
    attackDuration: 0.75,
    shardReward: 12,
    essenceReward: 22,
    materialDrop: 'Brine Scale',
    difficulty: 'Low',
    fishingDifficulty: 1,
    locationDiscovered: 'Shallow Basin · The Forgotten Shore',
    description:
      'An amphibious sentry clad in rotting kelp and clutching a corroded bronze trident. Though dim-eyed in life, the Abyssal hook rouses its ancient guard instincts.',
    combatNotes:
      'Stalks horizontally and swings a wide trident arc after a short windup. Bait the thrust, dash back, and counterattack.',
    loreNotes:
      'Once keepers of the Shore causeways before the Great Submersion dragged their Watch into the still waters.',
  },
  dartfin: {
    id: 'dartfin',
    name: 'Lantern Dartfin',
    category: 'Small Creature',
    rarity: 'Uncommon',
    maxHp: 4,
    damage: 1,
    moveSpeed: 3.4,
    detectionRange: 10,
    attackRange: 4.5,
    attackCooldown: 1.9,
    attackDuration: 0.55,
    shardReward: 18,
    essenceReward: 28,
    materialDrop: 'Luminescent Gland',
    difficulty: 'Moderate',
    fishingDifficulty: 2,
    locationDiscovered: 'Shallow Basin & Deepwell Pond',
    description:
      'A sleek, needle-jawed hunter bearing a pale phosphorescent lure. It skips rapidly across damp stone and fires pressurized brine bolts.',
    combatNotes:
      'Keeps medium range and spits glowing brine projectiles. Jump over the bolt or dash through it to close distance.',
    loreNotes:
      'Their glands still illuminate Old Mara’s lantern posts centuries after the lanterns’ oil ran dry.',
  },
  shellback: {
    id: 'shellback',
    name: 'Shellback Warden',
    category: 'Elite Creature',
    rarity: 'Rare',
    maxHp: 9,
    damage: 2,
    moveSpeed: 1.45,
    detectionRange: 7.5,
    attackRange: 1.65,
    attackCooldown: 2.1,
    attackDuration: 0.9,
    shardReward: 34,
    essenceReward: 40,
    materialDrop: 'Abyssal Carapace',
    difficulty: 'High',
    fishingDifficulty: 3,
    locationDiscovered: 'Shallow Basin & Deepwell Pond',
    description:
      'An armored crustacean colossus fused with sunken masonry. Its heavy claws shatter stone slabs when brought down in fury.',
    combatNotes:
      'High health and heavy 2-damage claw slam. Leap behind it during its windup or strike from mid-air.',
    loreNotes:
      'Masonry markings etched onto its shell match the Forgotten Temple deeper below.',
  },
  mire_eel: {
    id: 'mire_eel',
    name: 'Grotto Mire-Serpent',
    category: 'Abyssal Creature',
    rarity: 'Epic',
    maxHp: 11,
    damage: 2,
    moveSpeed: 3.8,
    detectionRange: 11,
    attackRange: 2.1,
    attackCooldown: 1.5,
    attackDuration: 0.65,
    shardReward: 55,
    essenceReward: 55,
    materialDrop: 'Void-Tendon Coil',
    difficulty: 'Very High',
    fishingDifficulty: 4,
    locationDiscovered: 'Deepwell Pond · Sunken Grotto',
    description:
      'A serpentine horror coiled in total darkness beneath the Sunken Grotto. Its violet spines crackle with abyssal static.',
    combatNotes:
      'Darts aggressively across the floor and lunges with rapid bites. Use Dash and Double Jump to stay above its strike lane.',
    loreNotes:
      'Drawn only to deepwells untouched by surface light; some claim it remembers the Shore before it sank.',
  },
  krakor_boss: {
    id: 'krakor_boss',
    name: 'Krakor, Drowned Sentinel',
    category: 'Boss Creature',
    rarity: 'Legendary',
    maxHp: 28,
    damage: 2,
    moveSpeed: 2.7,
    detectionRange: 18,
    attackRange: 2.2,
    attackCooldown: 1.35,
    attackDuration: 0.8,
    shardReward: 150,
    essenceReward: 100,
    materialDrop: 'Heart of the Shore',
    difficulty: 'Boss',
    fishingDifficulty: 5,
    locationDiscovered: 'The Drowned Maw · Forgotten Shore',
    description:
      'An ancient crowned leviathan-knight bound to the Abyssal Maw. Its rusted halberd hums with the tidal seal that keeps the deeper regions locked.',
    combatNotes:
      'Phase 1: Sweeping halberd lunges and leaping shockwave slams. Phase 2 (<50% HP): Enraged double lunges and erupting brine geysers from the arena floor.',
    loreNotes:
      'Last sworn guardian of the Forgotten Shore. Defeating Krakor proves the angler worthy of descending toward the Sunken Forest.',
    isBoss: true,
  },
};

export const ITEMS: Record<string, EquipmentItem> = {
  rod_basic: {
    id: 'rod_basic',
    kind: 'rod',
    name: 'Driftwood Rod',
    description: 'A weathered shore rod strung with sinew line. Catches Common and Uncommon abyssal life.',
    cost: 0,
    rodLevel: 1,
    rareBonus: 0,
    reelAssist: 0,
  },
  rod_reinforced: {
    id: 'rod_reinforced',
    kind: 'rod',
    name: 'Reinforced Bone Rod',
    description: 'Carved from leviathan ribs. Wider reel catch bar (+25%) and higher Rare/Epic odds.',
    cost: 35,
    rodLevel: 2,
    rareBonus: 0.25,
    reelAssist: 0.08,
  },
  rod_abyssal: {
    id: 'rod_abyssal',
    kind: 'rod',
    name: 'Abyssal Hook Rod',
    description: 'Forged with bioluminescent bronze. Calms erratic struggle and unlocks deep-abyss catches.',
    cost: 85,
    rodLevel: 3,
    rareBonus: 0.5,
    reelAssist: 0.14,
  },
  bait_none: {
    id: 'bait_none',
    kind: 'bait',
    name: 'Bare Iron Hook',
    description: 'Standard hook with no lure attached.',
    cost: 0,
    rareBonus: 0,
  },
  bait_glowworm: {
    id: 'bait_glowworm',
    kind: 'bait',
    name: 'Glowworm Lure',
    description: 'Bioluminescent bait that attracts Rare and Epic creatures from deep ponds.',
    cost: 20,
    rareBonus: 0.35,
  },
  blade_upgrade: {
    id: 'blade_upgrade',
    kind: 'blade',
    name: 'Tempered Hook-Blade',
    description: 'Hones your rod-hook edge, permanently increasing melee attack damage (+1 DMG).',
    cost: 45,
    damageBonus: 1,
  },
  vessel_shard: {
    id: 'vessel_shard',
    kind: 'vessel',
    name: 'Tide Vessel Shard',
    description: 'Reinforces your lantern shell, permanently increasing Maximum Health (+1 HP).',
    cost: 40,
    hpBonus: 1,
  },
  relic_shore_heart: {
    id: 'relic_shore_heart',
    kind: 'relic',
    name: 'Heart of the Shore',
    description: 'Seal claimed from Krakor, Drowned Sentinel. Opens passage toward the Sunken Forest.',
    cost: 0,
  },
};

export const ROOMS: Record<RoomId, RoomConfig> = {
  shore_landing: {
    id: 'shore_landing',
    name: 'Tidal Causeway',
    regionName: 'The Forgotten Shore',
    bounds: { minX: -12, maxX: 12, minY: -5, maxY: 7 },
    mapPos: { col: 1, row: 1 },
    ambientColorTop: '#0d192b',
    ambientColorBottom: '#19304d',
    colliders: [
      // Main causeway floor (top = -2.02)
      { x: 0, y: -2.6, w: 24, h: 1.16 },
      // Elevated ruin ledge on the left
      { x: -6.5, y: 0.25, w: 4.5, h: 0.65 },
      // Stepping stone platform
      { x: -2.2, y: -0.65, w: 2.4, h: 0.55 },
      // Upper archive perch
      { x: 5.5, y: 0.35, w: 3.6, h: 0.6 },
    ],
    platforms: [
      { x: -5.5, y: -2.54, w: 12.2, h: 1.03, style: 'platform_long' },
      { x: 5.5, y: -2.54, w: 12.2, h: 1.03, style: 'platform_long' },
      { x: -6.5, y: 0.25, w: 4.5, h: 0.65, style: 'bridge' },
      { x: -2.2, y: -0.65, w: 2.4, h: 0.55, style: 'stone_block' },
      { x: 5.5, y: 0.35, w: 3.6, h: 0.6, style: 'bridge' },
    ],
    exits: [
      {
        id: 'to_cliff_west',
        x: -11.6,
        y: -0.8,
        w: 0.9,
        h: 2.6,
        targetRoom: 'shore_cliff_west',
        spawnX: 9.8,
        spawnY: -1.35,
        label: "Angler's Watch",
        direction: 'left',
      },
      {
        id: 'to_pond_east',
        x: 11.6,
        y: -0.8,
        w: 0.9,
        h: 2.6,
        targetRoom: 'shore_pond_east',
        spawnX: -9.8,
        spawnY: -1.35,
        label: 'Shallow Basin',
        direction: 'right',
      },
    ],
    ponds: [],
    breakableWalls: [],
    saveShrines: [
      {
        id: 'shrine_causeway',
        name: 'Causeway Tide Lantern',
        x: -0.2,
        y: -2.02,
      },
    ],
    pickups: [],
    loreTablets: [
      {
        id: 'tablet_causeway',
        title: 'Weathered Tide Tablet',
        x: 3.2,
        y: -2.02,
        lines: [
          '“No beast walks the Forgotten Shore by its own will. When the Abyss swallowed the old kingdom, every living shadow sank beneath the mirror-water.”',
          '“Only the iron hook may draw them back to breath—and only steel may lay them to rest.”',
        ],
      },
    ],
    npcs: [],
    decorations: [
      { type: 'arch', x: -11.2, y: -2.02, scale: 1.1 },
      { type: 'arch', x: 11.2, y: -2.02, scale: 1.1 },
      { type: 'pillar', x: -7.5, y: 0.58, scale: 1.0 },
      { type: 'mushroom', x: 5.2, y: 0.65, scale: 1.1 },
      { type: 'mushroom', x: -4.2, y: -2.02, scale: 0.9 },
      { type: 'lamp', x: -0.9, y: -2.02, scale: 1.0 },
    ],
  },

  shore_cliff_west: {
    id: 'shore_cliff_west',
    name: "Angler's Watch",
    regionName: 'The Forgotten Shore',
    bounds: { minX: -12, maxX: 12, minY: -5, maxY: 8 },
    mapPos: { col: 0, row: 1 },
    ambientColorTop: '#0b1628',
    ambientColorBottom: '#162b47',
    colliders: [
      // Right landing floor (NPC Mara lives here)
      { x: 6.2, y: -2.6, w: 11.6, h: 1.16 },
      // Left abyssal cliff floor
      { x: -7.5, y: -2.6, w: 9.0, h: 1.16 },
      // Vertical tower steps climbing up to the Dash Relic
      { x: 1.8, y: -0.45, w: 3.0, h: 0.6 },
      { x: 5.8, y: 1.3, w: 3.2, h: 0.6 },
      { x: 0.6, y: 2.9, w: 3.6, h: 0.6 },
      // Left relic shrine platform across chasm (requires stepping or dash back)
      { x: -7.6, y: 3.05, w: 5.2, h: 0.7 },
      // West boundary wall
      { x: -12.4, y: 1.5, w: 0.8, h: 12 },
    ],
    platforms: [
      { x: 6.2, y: -2.54, w: 11.6, h: 1.03, style: 'platform_long' },
      { x: -7.5, y: -2.54, w: 9.0, h: 1.03, style: 'platform_long' },
      { x: 1.8, y: -0.45, w: 3.0, h: 0.6, style: 'stone_block' },
      { x: 5.8, y: 1.3, w: 3.2, h: 0.6, style: 'bridge' },
      { x: 0.6, y: 2.9, w: 3.6, h: 0.6, style: 'bridge' },
      { x: -7.6, y: 3.05, w: 5.2, h: 0.7, style: 'platform_long' },
    ],
    exits: [
      {
        id: 'to_landing_east',
        x: 11.6,
        y: -0.8,
        w: 0.9,
        h: 2.6,
        targetRoom: 'shore_landing',
        spawnX: -9.8,
        spawnY: -1.35,
        label: 'Tidal Causeway',
        direction: 'right',
      },
    ],
    ponds: [],
    breakableWalls: [],
    saveShrines: [],
    pickups: [
      {
        id: 'relic_dash',
        ability: 'dash',
        title: 'Abyssal Surge',
        description:
          'Press [Shift] or [L] to surge forward through attacks and cross wide abyssal chasms.',
        x: -7.8,
        y: 3.7,
      },
    ],
    loreTablets: [
      {
        id: 'tablet_watch',
        title: 'Watchtower Inscription',
        x: -7.4,
        y: -2.02,
        lines: [
          '“Across the broken span above rests the Surge Rune. Even without wings, a bold leap from the upper archway reaches the chasm edge.”',
        ],
      },
    ],
    npcs: [
      {
        id: 'npc_mara',
        name: 'Old Mara',
        title: 'Shore Tackle-Smith',
        x: 7.4,
        y: -2.02,
        dialogue: [
          'Another lantern-bearer waking on the Shore? Keep your line dry and your hook sharp.',
          'The waters hold everything that vanished in the Great Submersion. Cast your line at any glowing pond—what bites will climb onto stone to test your steel.',
          'Bring me Tide Shards from defeated catches. I can temper your hook-blade, mend your vessels, or forge a rod strong enough for the Drowned Maw.',
        ],
      },
    ],
    decorations: [
      { type: 'arch', x: 11.2, y: -2.02, scale: 1.1 },
      { type: 'lamp', x: 6.4, y: -2.02, scale: 1.0 },
      { type: 'pillar', x: -9.6, y: 3.4, scale: 1.0 },
      { type: 'mushroom', x: 5.4, y: 1.6, scale: 1.1 },
      { type: 'crystal', x: -6.2, y: -2.02, scale: 1.0 },
    ],
  },

  shore_pond_east: {
    id: 'shore_pond_east',
    name: 'Shallow Basin',
    regionName: 'The Forgotten Shore',
    bounds: { minX: -12, maxX: 14, minY: -5, maxY: 9 },
    mapPos: { col: 2, row: 1 },
    ambientColorTop: '#0d1d31',
    ambientColorBottom: '#16354f',
    colliders: [
      // Left approach platform (top = -2.02)
      { x: -6.2, y: -2.6, w: 11.6, h: 1.16 },
      // Cave pond basin floor (aligns seamlessly at -2.02!)
      { x: 4.8, y: -4.22, w: 10.6, h: 4.4 },
      // Right landing shelf after pond
      { x: 12.1, y: -2.6, w: 4.0, h: 1.16 },
      // Mid-air stone platforms leading upward toward Overlook
      { x: -4.6, y: 0.45, w: 3.2, h: 0.6 },
      { x: 1.2, y: 2.3, w: 3.4, h: 0.6 },
      // High overlook ledge (needs Double Jump or clever route from above)
      { x: 7.4, y: 4.4, w: 5.2, h: 0.65 },
      // Upper ceiling wall separating left & right
      { x: 13.9, y: 1.5, w: 0.8, h: 14 },
    ],
    platforms: [
      { x: -6.2, y: -2.54, w: 11.6, h: 1.03, style: 'platform_long' },
      { x: 12.1, y: -2.54, w: 4.0, h: 1.03, style: 'stone_block' },
      { x: -4.6, y: 0.45, w: 3.2, h: 0.6, style: 'bridge' },
      { x: 1.2, y: 2.3, w: 3.4, h: 0.6, style: 'bridge' },
      { x: 7.4, y: 4.4, w: 5.2, h: 0.65, style: 'platform_long' },
    ],
    exits: [
      {
        id: 'to_landing_west',
        x: -11.6,
        y: -0.8,
        w: 0.9,
        h: 2.6,
        targetRoom: 'shore_landing',
        spawnX: 9.8,
        spawnY: -1.35,
        label: 'Tidal Causeway',
        direction: 'left',
      },
      {
        id: 'to_grotto_east',
        x: 13.4,
        y: -0.8,
        w: 0.9,
        h: 2.6,
        targetRoom: 'sunken_grotto',
        spawnX: -9.8,
        spawnY: -1.35,
        label: 'Sunken Grotto',
        direction: 'right',
      },
      {
        id: 'to_overlook_up',
        x: 8.6,
        y: 6.75,
        w: 2.6,
        h: 1.2,
        targetRoom: 'shore_overlook',
        spawnX: -8.2,
        spawnY: -1.35,
        label: 'Upper Sanctum',
        direction: 'up',
      },
    ],
    ponds: [
      {
        id: 'pond_shallow_basin',
        name: 'Shallow Basin Pond',
        description: 'Clear subterranean tidewater where Trench Skirmishers and Lantern Dartfins lurk.',
        x: 4.8,
        y: -2.51,
        w: 10.56,
        h: 7.92,
        zoneX: 4.8,
        zoneY: -1.4,
        zoneW: 8.6,
        zoneH: 2.1,
        visualType: 'cave_pond_asset',
        pool: [
          { creatureId: 'skirmisher', weight: 58, minRodLevel: 1 },
          { creatureId: 'dartfin', weight: 28, minRodLevel: 1 },
          { creatureId: 'shellback', weight: 14, minRodLevel: 1 },
        ],
      },
    ],
    breakableWalls: [
      {
        id: 'wall_grotto_entrance',
        x: 12.6,
        y: -0.5,
        w: 0.9,
        h: 3.05,
        hp: 3,
      },
    ],
    saveShrines: [],
    pickups: [],
    loreTablets: [],
    npcs: [],
    decorations: [
      { type: 'arch', x: -11.2, y: -2.02, scale: 1.1 },
      { type: 'arch', x: 8.6, y: 4.725, scale: 1.0 },
      { type: 'mushroom', x: -5.2, y: 0.75, scale: 1.0 },
      { type: 'crystal', x: 1.4, y: 2.6, scale: 0.9 },
      { type: 'lamp', x: 6.0, y: 4.725, scale: 1.0 },
    ],
  },

  sunken_grotto: {
    id: 'sunken_grotto',
    name: 'Sunken Grotto',
    regionName: 'The Forgotten Shore',
    bounds: { minX: -12, maxX: 12, minY: -5, maxY: 7 },
    mapPos: { col: 3, row: 1 },
    ambientColorTop: '#081224',
    ambientColorBottom: '#132544',
    colliders: [
      // Left entry shelf
      { x: -8.0, y: -2.6, w: 8.0, h: 1.16 },
      // Deepwell Pond floor
      { x: 0.5, y: -3.1, w: 9.2, h: 2.16 },
      // Right shrine dais
      { x: 8.5, y: -2.6, w: 7.0, h: 1.16 },
      // High mushroom perch
      { x: 1.2, y: 0.4, w: 3.5, h: 0.55 },
      // East boundary wall
      { x: 12.4, y: 1.5, w: 0.8, h: 12 },
    ],
    platforms: [
      { x: -8.0, y: -2.54, w: 8.0, h: 1.03, style: 'platform_long' },
      { x: 8.5, y: -2.54, w: 7.0, h: 1.03, style: 'platform_long' },
      { x: 1.2, y: 0.4, w: 3.5, h: 0.55, style: 'bridge' },
    ],
    exits: [
      {
        id: 'to_pond_west',
        x: -11.6,
        y: -0.8,
        w: 0.9,
        h: 2.6,
        targetRoom: 'shore_pond_east',
        spawnX: 11.1,
        spawnY: -1.35,
        label: 'Shallow Basin',
        direction: 'left',
      },
    ],
    ponds: [
      {
        id: 'pond_deepwell',
        name: 'Grotto Deepwell',
        description: 'Bioluminescent abyssal spring hiding Rare Shellbacks and the Epic Mire-Serpent.',
        x: 0.5,
        y: -2.02,
        w: 8.8,
        h: 3.6,
        zoneX: 0.5,
        zoneY: -1.4,
        zoneW: 8.0,
        zoneH: 2.2,
        visualType: 'deepwell',
        pool: [
          { creatureId: 'dartfin', weight: 32, minRodLevel: 1 },
          { creatureId: 'shellback', weight: 38, minRodLevel: 1 },
          { creatureId: 'mire_eel', weight: 30, minRodLevel: 1 },
        ],
      },
    ],
    breakableWalls: [],
    saveShrines: [],
    pickups: [
      {
        id: 'relic_double_jump',
        ability: 'doubleJump',
        title: 'Tidal Wings',
        description:
          'Press [Space] again mid-air to perform a Double Jump and reach the Upper Sanctum.',
        x: 8.6,
        y: -1.45,
      },
    ],
    loreTablets: [],
    npcs: [],
    decorations: [
      { type: 'arch', x: -11.2, y: -2.02, scale: 1.1 },
      { type: 'crystal', x: -5.8, y: -2.02, scale: 1.2 },
      { type: 'crystal', x: 6.4, y: -2.02, scale: 1.3 },
      { type: 'mushroom', x: 1.2, y: 0.68, scale: 1.3 },
      { type: 'mushroom', x: 9.8, y: -2.02, scale: 1.1 },
    ],
  },

  shore_overlook: {
    id: 'shore_overlook',
    name: 'Upper Sanctum',
    regionName: 'The Forgotten Shore',
    bounds: { minX: -12, maxX: 12, minY: -5, maxY: 7 },
    mapPos: { col: 2, row: 0 },
    ambientColorTop: '#0d1a30',
    ambientColorBottom: '#1c3659',
    colliders: [
      // Left entry ledge
      { x: -7.5, y: -2.6, w: 9.0, h: 1.16 },
      // Center bridge span
      { x: 0.5, y: -1.2, w: 4.0, h: 0.6 },
      // Right sanctum floor
      { x: 7.5, y: -2.6, w: 9.0, h: 1.16 },
      // West boundary wall
      { x: -12.4, y: 1.5, w: 0.8, h: 12 },
    ],
    platforms: [
      { x: -7.5, y: -2.54, w: 9.0, h: 1.03, style: 'platform_long' },
      { x: 0.5, y: -1.2, w: 4.0, h: 0.6, style: 'bridge' },
      { x: 7.5, y: -2.54, w: 9.0, h: 1.03, style: 'platform_long' },
    ],
    exits: [
      {
        id: 'to_pond_down',
        x: -11.3,
        y: -0.8,
        w: 1.5,
        h: 2.6,
        targetRoom: 'shore_pond_east',
        spawnX: 5.8,
        spawnY: 5.16,
        label: 'Shallow Basin',
        direction: 'down',
      },
      {
        id: 'to_boss_east',
        x: 11.6,
        y: -0.8,
        w: 0.9,
        h: 2.6,
        targetRoom: 'boss_maw',
        spawnX: -9.8,
        spawnY: -1.35,
        label: 'The Drowned Maw',
        direction: 'right',
      },
    ],
    ponds: [],
    breakableWalls: [],
    saveShrines: [
      {
        id: 'shrine_overlook',
        name: 'Sanctum Tide Lantern',
        x: -5.4,
        y: -2.02,
      },
    ],
    pickups: [
      {
        id: 'cache_overlook_shards',
        shards: 35,
        title: 'Sunken Shard Coffer',
        description: 'Recovered 35 Tide Shards from the Sanctum watch.',
        x: 0.5,
        y: -0.35,
      },
    ],
    loreTablets: [
      {
        id: 'tablet_overlook',
        title: 'Sanctum Warning',
        x: 6.8,
        y: -2.02,
        lines: [
          '“Beyond this gate lies the Drowned Maw. Cast your hook only when your blade and vessels are prepared for Krakor, the Drowned Sentinel.”',
        ],
      },
    ],
    npcs: [],
    decorations: [
      { type: 'arch', x: -11.2, y: -2.02, scale: 1.1 },
      { type: 'arch', x: 11.2, y: -2.02, scale: 1.1 },
      { type: 'lamp', x: -5.9, y: -2.02, scale: 1.0 },
      { type: 'pillar', x: -3.2, y: -2.02, scale: 1.1 },
      { type: 'crystal', x: 4.5, y: -2.02, scale: 1.0 },
    ],
  },

  boss_maw: {
    id: 'boss_maw',
    name: 'The Drowned Maw',
    regionName: 'The Forgotten Shore',
    bounds: { minX: -12, maxX: 12, minY: -5, maxY: 8 },
    mapPos: { col: 3, row: 0 },
    ambientColorTop: '#160d1f',
    ambientColorBottom: '#291a38',
    colliders: [
      // Left entry platform
      { x: -6.5, y: -2.6, w: 11.0, h: 1.16 },
      // Boss Maw pool floor
      { x: 3.5, y: -3.2, w: 9.2, h: 2.36 },
      // Right arena floor
      { x: 10.0, y: -2.6, w: 4.2, h: 1.16 },
      // Two side aerial perches for dodging Krakor's ground slams
      { x: -5.5, y: 0.65, w: 3.0, h: 0.55 },
      { x: 6.5, y: 0.65, w: 3.0, h: 0.55 },
      // East boundary wall
      { x: 12.4, y: 1.5, w: 0.8, h: 12 },
    ],
    platforms: [
      { x: -6.5, y: -2.54, w: 11.0, h: 1.03, style: 'platform_long' },
      { x: 10.0, y: -2.54, w: 4.2, h: 1.03, style: 'stone_block' },
      { x: -5.5, y: 0.65, w: 3.0, h: 0.55, style: 'bridge' },
      { x: 6.5, y: 0.65, w: 3.0, h: 0.55, style: 'bridge' },
    ],
    exits: [
      {
        id: 'to_overlook_west',
        x: -11.6,
        y: -0.8,
        w: 0.9,
        h: 2.6,
        targetRoom: 'shore_overlook',
        spawnX: 9.8,
        spawnY: -1.35,
        label: 'Upper Sanctum',
        direction: 'left',
      },
    ],
    ponds: [
      {
        id: 'pond_drowned_maw',
        name: 'The Abyssal Maw',
        description:
          'A churning crimson-violet vortex. Only the guardian Krakor, Drowned Sentinel answers a hook cast here.',
        x: 3.5,
        y: -2.02,
        w: 9.0,
        h: 3.6,
        zoneX: 3.5,
        zoneY: -1.4,
        zoneW: 8.4,
        zoneH: 2.2,
        visualType: 'maw_whirlpool',
        pool: [{ creatureId: 'krakor_boss', weight: 100, minRodLevel: 1 }],
      },
    ],
    breakableWalls: [],
    saveShrines: [],
    pickups: [],
    loreTablets: [],
    npcs: [],
    decorations: [
      { type: 'arch', x: -11.2, y: -2.02, scale: 1.1 },
      { type: 'crystal', x: -8.5, y: -2.02, scale: 1.3 },
      { type: 'crystal', x: 10.6, y: -2.02, scale: 1.3 },
      { type: 'pillar', x: -5.5, y: 0.93, scale: 0.9 },
      { type: 'pillar', x: 6.5, y: 0.93, scale: 0.9 },
    ],
  },
};

export const WORLD_REGIONS_PREVIEW = [
  { id: 'forgotten_shore', name: '1. The Forgotten Shore', status: 'Playable Vertical Slice (6 Rooms)' },
  { id: 'sunken_forest', name: '2. The Sunken Forest', status: 'Beyond Shore Seal' },
  { id: 'drowned_city', name: '3. The Drowned City', status: 'Planned Region' },
  { id: 'crystal_caverns', name: '4. The Crystal Caverns', status: 'Planned Region' },
  { id: 'abyssal_trench', name: '5. The Abyssal Trench', status: 'Planned Region' },
  { id: 'forgotten_temple', name: '6. The Forgotten Temple', status: 'Planned Region' },
  { id: 'heart_abyss', name: '7. The Heart of the Abyss', status: 'Planned Region' },
];
