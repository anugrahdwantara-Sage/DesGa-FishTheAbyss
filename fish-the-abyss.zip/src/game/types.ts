export type Rarity = 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary' | 'Abyssal';

export type EnemyKind = 'skirmisher' | 'dartfin' | 'shellback' | 'mire_eel' | 'krakor_boss';

export type RoomId =
  | 'shore_landing'
  | 'shore_pond_east'
  | 'shore_cliff_west'
  | 'sunken_grotto'
  | 'shore_overlook'
  | 'boss_maw';

export type RegionId = 'forgotten_shore' | 'sunken_grotto_sub';

export interface AABB {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface PlatformTile {
  x: number;
  y: number;
  w: number;
  h: number;
  style: 'platform_long' | 'stone_block' | 'ruin_pillar' | 'bridge';
}

export interface RoomExit {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  targetRoom: RoomId;
  spawnX: number;
  spawnY: number;
  label: string;
  direction: 'left' | 'right' | 'up' | 'down';
}

export interface PondConfig {
  id: string;
  name: string;
  description: string;
  x: number;
  y: number;
  w: number;
  h: number;
  zoneX: number;
  zoneY: number;
  zoneW: number;
  zoneH: number;
  visualType: 'cave_pond_asset' | 'deepwell' | 'maw_whirlpool';
  pool: { creatureId: EnemyKind; weight: number; minRodLevel: number }[];
}

export interface BreakableWallConfig {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  hp: number;
}

export interface SaveShrineConfig {
  id: string;
  name: string;
  x: number;
  y: number;
}

export interface RelicPickupConfig {
  id: string;
  ability?: 'dash' | 'doubleJump' | 'wallCling';
  itemId?: string;
  shards?: number;
  title: string;
  description: string;
  x: number;
  y: number;
}

export interface LoreTabletConfig {
  id: string;
  title: string;
  lines: string[];
  x: number;
  y: number;
}

export interface NpcConfig {
  id: string;
  name: string;
  title: string;
  x: number;
  y: number;
  dialogue: string[];
}

export interface RoomConfig {
  id: RoomId;
  name: string;
  regionName: string;
  bounds: { minX: number; maxX: number; minY: number; maxY: number };
  mapPos: { col: number; row: number };
  ambientColorTop: string;
  ambientColorBottom: string;
  colliders: AABB[];
  platforms: PlatformTile[];
  exits: RoomExit[];
  ponds: PondConfig[];
  breakableWalls: BreakableWallConfig[];
  saveShrines: SaveShrineConfig[];
  pickups: RelicPickupConfig[];
  loreTablets: LoreTabletConfig[];
  npcs: NpcConfig[];
  decorations: {
    type: 'mushroom' | 'lamp' | 'chain' | 'pillar' | 'arch' | 'crystal';
    x: number;
    y: number;
    scale?: number;
  }[];
}

export interface CreatureDefinition {
  id: EnemyKind;
  name: string;
  category: string;
  rarity: Rarity;
  maxHp: number;
  damage: number;
  moveSpeed: number;
  detectionRange: number;
  attackRange: number;
  attackCooldown: number;
  attackDuration: number;
  shardReward: number;
  essenceReward: number;
  materialDrop: string;
  difficulty: string;
  fishingDifficulty: number; // 1 (calm) to 5 (frenetic)
  locationDiscovered: string;
  description: string;
  combatNotes: string;
  loreNotes: string;
  isBoss?: boolean;
}

export interface EquipmentItem {
  id: string;
  kind: 'rod' | 'bait' | 'blade' | 'vessel' | 'material' | 'relic';
  name: string;
  description: string;
  cost: number;
  rodLevel?: number;
  rareBonus?: number;
  reelAssist?: number;
  damageBonus?: number;
  hpBonus?: number;
}

export interface JournalEntry {
  caughtCount: number;
  defeatedCount: number;
  firstLocation: string;
}

export type FishingPhase =
  | 'IDLE'
  | 'CASTING'
  | 'WAITING_BITE'
  | 'BITE_WINDOW'
  | 'REELING'
  | 'CATCH_REVEAL';

export interface FishingState {
  phase: FishingPhase;
  pondId: string | null;
  pondName: string;
  timer: number;
  biteTimer: number;
  hookedCreature: CreatureDefinition | null;
  // Reeling minigame (0..1)
  barPos: number;
  barVel: number;
  barHalfSize: number;
  fishPos: number;
  fishVel: number;
  fishTarget: number;
  fishMoveTimer: number;
  catchProgress: number;
  tension: number;
}

export interface GameSettings {
  masterVolume: number;
  muted: boolean;
  showHitboxes: boolean;
  touchControls: 'auto' | 'on' | 'off';
}

export interface SaveData {
  version: number;
  roomId: RoomId;
  respawnRoomId: RoomId;
  respawnX: number;
  respawnY: number;
  hp: number;
  maxHp: number;
  essence: number;
  shards: number;
  abilities: {
    dash: boolean;
    doubleJump: boolean;
    wallCling: boolean;
  };
  equippedRod: string;
  equippedBait: string;
  ownedItems: Record<string, number>;
  attackDamage: number;
  brokenWalls: string[];
  collectedPickups: string[];
  visitedRooms: RoomId[];
  discoveredPonds: string[];
  defeatedBosses: string[];
  journal: Record<string, JournalEntry>;
}

export interface HudSnapshot {
  roomId: RoomId;
  roomName: string;
  regionName: string;
  hp: number;
  maxHp: number;
  essence: number;
  shards: number;
  equippedRodName: string;
  equippedBaitName: string;
  abilities: SaveData['abilities'];
  activeEnemies: number;
  bossActive: { name: string; hp: number; maxHp: number; phase: number } | null;
  fishing: FishingState;
  nearbyPrompt: { label: string; action: 'fish' | 'save' | 'npc' | 'lore' | 'pickup' } | null;
  toastMessage: string | null;
  alive: boolean;
  fellInAbyss: boolean;
  arenaLocked: boolean;
}
