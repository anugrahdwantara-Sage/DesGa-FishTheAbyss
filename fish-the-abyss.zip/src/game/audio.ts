class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private ambienceStarted = false;
  private volume = 0.55;
  private muted = false;

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.muted ? 0 : this.volume;
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  setVolume(vol: number, muted: boolean) {
    this.volume = Math.max(0, Math.min(1, vol));
    this.muted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        this.muted ? 0 : this.volume,
        this.ctx.currentTime,
        0.04,
      );
    }
  }

  startAmbience() {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || this.ambienceStarted) return;
    this.ambienceStarted = true;

    // Subtle subterranean cavern drone
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.value = 54;
    filter.type = 'lowpass';
    filter.frequency.value = 140;
    gain.gain.value = 0.045;
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    osc.start();
  }

  private playTone(
    freq: number,
    endFreq: number,
    duration: number,
    type: OscillatorType,
    gainPeak: number,
  ) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || this.muted) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), now + duration);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(gainPeak, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  jump() {
    this.playTone(190, 420, 0.14, 'triangle', 0.14);
  }

  doubleJump() {
    this.playTone(280, 560, 0.16, 'sine', 0.15);
  }

  dash() {
    this.playTone(460, 110, 0.16, 'sawtooth', 0.1);
  }

  slash() {
    this.playTone(540, 160, 0.09, 'triangle', 0.14);
  }

  hitEnemy() {
    this.playTone(170, 75, 0.11, 'square', 0.15);
  }

  hitPlayer() {
    this.playTone(140, 55, 0.22, 'sawtooth', 0.2);
  }

  castSplash() {
    this.playTone(320, 140, 0.22, 'sine', 0.14);
    setTimeout(() => this.playTone(520, 220, 0.16, 'triangle', 0.09), 90);
  }

  biteAlert() {
    this.playTone(760, 1140, 0.18, 'sine', 0.2);
    setTimeout(() => this.playTone(980, 1320, 0.18, 'sine', 0.18), 80);
  }

  catchSuccess() {
    this.playTone(392, 392, 0.14, 'triangle', 0.16);
    setTimeout(() => this.playTone(493.88, 493.88, 0.14, 'triangle', 0.16), 90);
    setTimeout(() => this.playTone(587.33, 659.25, 0.28, 'triangle', 0.18), 180);
  }

  lineSnap() {
    this.playTone(260, 90, 0.28, 'sawtooth', 0.16);
  }

  saveChime() {
    this.playTone(440, 440, 0.2, 'sine', 0.14);
    setTimeout(() => this.playTone(659.25, 659.25, 0.35, 'sine', 0.14), 110);
  }

  heal() {
    this.playTone(330, 660, 0.32, 'sine', 0.15);
  }

  bossRoar() {
    this.playTone(110, 48, 0.55, 'sawtooth', 0.24);
  }
}

export const soundEngine = new SoundEngine();
