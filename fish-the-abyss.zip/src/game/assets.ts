export interface SpriteSlice {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface AnimFrame {
  time: number;
  slice: SpriteSlice;
}

export interface AnimationClip {
  sheet: string;
  duration: number;
  loop: boolean;
  frames: AnimFrame[];
  eventTime?: number;
}

export const SPRITE_PATHS = {
  mcIdle: '/sprites/mc/idle.png',
  mcRun: '/sprites/mc/run.png',
  mcJump: '/sprites/mc/jump.png',
  mcFall: '/sprites/mc/fall.png',
  mcAttack: '/sprites/mc/attack.png',
  mcFishing: '/sprites/mc/fishing.png',
  enemyIdle: '/sprites/enemy1/idle.png',
  enemyWalk: '/sprites/enemy1/walk.png',
  enemyAttack: '/sprites/enemy1/attack.png',
  enemyBreach: '/sprites/enemy1/breach.png',
  cavePond: '/sprites/world/cave-pond.png',
  ground: '/sprites/world/ground.png',
} as const;

export const WORLD_SPRITES = {
  platform: {
    sheet: SPRITE_PATHS.ground,
    slice: { x: 611, y: 0, w: 514, h: 65 },
  },
  groundTile: {
    sheet: SPRITE_PATHS.ground,
    slice: { x: 0, y: 0, w: 65, h: 65 },
  },
  groundTileAlt: {
    sheet: SPRITE_PATHS.ground,
    slice: { x: 203, y: 0, w: 66, h: 65 },
  },
  cavePond: {
    sheet: SPRITE_PATHS.cavePond,
    duration: 1.0,
    loop: true,
    frames: [
      { time: 0.0, slice: { x: 0, y: 0, w: 640, h: 480 } },
      { time: 0.125, slice: { x: 640, y: 0, w: 640, h: 480 } },
      { time: 0.25, slice: { x: 1280, y: 0, w: 640, h: 480 } },
      { time: 0.375, slice: { x: 0, y: 480, w: 640, h: 480 } },
      { time: 0.5, slice: { x: 640, y: 480, w: 640, h: 480 } },
      { time: 0.625, slice: { x: 1280, y: 480, w: 640, h: 480 } },
      { time: 0.75, slice: { x: 0, y: 960, w: 640, h: 480 } },
      { time: 0.875, slice: { x: 640, y: 960, w: 640, h: 480 } },
    ],
  } satisfies AnimationClip,
};

export type McAnimName = 'idle' | 'run' | 'jump' | 'fall' | 'attack' | 'fishing';

export const MC_ANIMS: Record<McAnimName, AnimationClip> = {
  idle: {
    sheet: SPRITE_PATHS.mcIdle,
    duration: 0.85,
    loop: true,
    frames: [
      { time: 0.0, slice: { x: 0, y: 0, w: 160, h: 160 } },
      { time: 0.1667, slice: { x: 160, y: 0, w: 160, h: 160 } },
      { time: 0.3333, slice: { x: 320, y: 0, w: 160, h: 160 } },
      { time: 0.5, slice: { x: 480, y: 0, w: 160, h: 160 } },
      { time: 0.6667, slice: { x: 640, y: 0, w: 160, h: 160 } },
      { time: 0.8333, slice: { x: 800, y: 0, w: 160, h: 160 } },
    ],
  },
  run: {
    sheet: SPRITE_PATHS.mcRun,
    duration: 0.9333,
    loop: true,
    frames: [
      { time: 0.0, slice: { x: 166, y: 3, w: 151, h: 151 } },
      { time: 0.1667, slice: { x: 324, y: 4, w: 153, h: 152 } },
      { time: 0.3333, slice: { x: 481, y: 3, w: 160, h: 153 } },
      { time: 0.5, slice: { x: 639, y: 3, w: 162, h: 155 } },
      { time: 0.6667, slice: { x: 803, y: 5, w: 155, h: 154 } },
      { time: 0.9167, slice: { x: 965, y: 5, w: 152, h: 154 } },
    ],
  },
  jump: {
    sheet: SPRITE_PATHS.mcJump,
    duration: 0.4167,
    loop: false,
    frames: [
      { time: 0.0, slice: { x: 23, y: 43, w: 136, h: 145 } },
      { time: 0.1, slice: { x: 199, y: 13, w: 109, h: 174 } },
      { time: 0.2, slice: { x: 350, y: 9, w: 122, h: 170 } },
      { time: 0.3, slice: { x: 505, y: 4, w: 128, h: 165 } },
      { time: 0.4, slice: { x: 668, y: 11, w: 129, h: 154 } },
    ],
  },
  fall: {
    sheet: SPRITE_PATHS.mcFall,
    duration: 0.4167,
    loop: true,
    frames: [
      { time: 0.0, slice: { x: 27, y: 8, w: 133, h: 155 } },
      { time: 0.1, slice: { x: 184, y: 4, w: 137, h: 156 } },
      { time: 0.2, slice: { x: 343, y: 4, w: 136, h: 157 } },
      { time: 0.3, slice: { x: 504, y: 4, w: 137, h: 157 } },
      { time: 0.4, slice: { x: 664, y: 4, w: 136, h: 155 } },
    ],
  },
  attack: {
    sheet: SPRITE_PATHS.mcAttack,
    duration: 0.2167,
    loop: false,
    eventTime: 0.05,
    frames: [
      { time: 0.0, slice: { x: 0, y: 0, w: 460, h: 160 } },
      { time: 0.0833, slice: { x: 460, y: 0, w: 460, h: 160 } },
      { time: 0.2, slice: { x: 920, y: 0, w: 460, h: 160 } },
    ],
  },
  fishing: {
    sheet: SPRITE_PATHS.mcFishing,
    duration: 0.2667,
    loop: false,
    frames: [
      { time: 0.0, slice: { x: 31, y: 4, w: 124, h: 156 } },
      { time: 0.0833, slice: { x: 189, y: 4, w: 124, h: 156 } },
      { time: 0.25, slice: { x: 351, y: 4, w: 124, h: 156 } },
    ],
  },
};

export type EnemyAnimName = 'idle' | 'walk' | 'attack' | 'breach';

export const ENEMY_ANIMS: Record<EnemyAnimName, AnimationClip> = {
  idle: {
    sheet: SPRITE_PATHS.enemyIdle,
    duration: 0.6667,
    loop: true,
    frames: [
      { time: 0.0, slice: { x: 34, y: 32, w: 108, h: 100 } },
      { time: 0.0833, slice: { x: 194, y: 32, w: 108, h: 100 } },
      { time: 0.1667, slice: { x: 354, y: 33, w: 107, h: 99 } },
      { time: 0.25, slice: { x: 514, y: 33, w: 107, h: 99 } },
      { time: 0.3333, slice: { x: 674, y: 33, w: 108, h: 99 } },
      { time: 0.4167, slice: { x: 834, y: 33, w: 108, h: 99 } },
      { time: 0.5, slice: { x: 994, y: 32, w: 108, h: 100 } },
      { time: 0.5833, slice: { x: 1154, y: 32, w: 108, h: 100 } },
    ],
  },
  walk: {
    sheet: SPRITE_PATHS.enemyWalk,
    duration: 0.6667,
    loop: true,
    frames: [
      { time: 0.0, slice: { x: 34, y: 33, w: 108, h: 99 } },
      { time: 0.0833, slice: { x: 192, y: 32, w: 109, h: 100 } },
      { time: 0.1667, slice: { x: 352, y: 32, w: 111, h: 100 } },
      { time: 0.25, slice: { x: 512, y: 32, w: 111, h: 99 } },
      { time: 0.3333, slice: { x: 674, y: 33, w: 108, h: 98 } },
      { time: 0.4167, slice: { x: 836, y: 32, w: 105, h: 99 } },
      { time: 0.5, slice: { x: 996, y: 32, w: 105, h: 100 } },
      { time: 0.5833, slice: { x: 1156, y: 32, w: 105, h: 100 } },
    ],
  },
  attack: {
    sheet: SPRITE_PATHS.enemyAttack,
    duration: 0.75,
    loop: false,
    eventTime: 0.25,
    frames: [
      { time: 0.0, slice: { x: 0, y: 0, w: 400, h: 160 } },
      { time: 0.0833, slice: { x: 400, y: 0, w: 400, h: 160 } },
      { time: 0.1667, slice: { x: 800, y: 0, w: 400, h: 160 } },
      { time: 0.25, slice: { x: 0, y: 160, w: 400, h: 160 } },
      { time: 0.3333, slice: { x: 400, y: 160, w: 400, h: 160 } },
      { time: 0.4167, slice: { x: 800, y: 160, w: 400, h: 160 } },
      { time: 0.5, slice: { x: 0, y: 320, w: 400, h: 160 } },
      { time: 0.5833, slice: { x: 400, y: 320, w: 400, h: 160 } },
      { time: 0.6667, slice: { x: 800, y: 320, w: 400, h: 160 } },
    ],
  },
  breach: {
    sheet: SPRITE_PATHS.enemyBreach,
    duration: 0.8333,
    loop: false,
    frames: [
      { time: 0.0, slice: { x: 0, y: 0, w: 160, h: 352 } },
      { time: 0.0833, slice: { x: 160, y: 0, w: 160, h: 352 } },
      { time: 0.1667, slice: { x: 320, y: 0, w: 160, h: 352 } },
      { time: 0.25, slice: { x: 480, y: 0, w: 160, h: 352 } },
      { time: 0.3333, slice: { x: 640, y: 0, w: 160, h: 352 } },
      { time: 0.4167, slice: { x: 800, y: 0, w: 160, h: 352 } },
      { time: 0.5, slice: { x: 960, y: 0, w: 160, h: 352 } },
      { time: 0.5833, slice: { x: 1120, y: 0, w: 160, h: 352 } },
      { time: 0.6667, slice: { x: 1280, y: 0, w: 160, h: 352 } },
      { time: 0.75, slice: { x: 1440, y: 0, w: 160, h: 352 } },
    ],
  },
};

export function sampleClipFrame(clip: AnimationClip, time: number): SpriteSlice {
  const t = clip.loop
    ? ((time % clip.duration) + clip.duration) % clip.duration
    : Math.min(time, clip.duration);
  let chosen = clip.frames[0].slice;
  for (let i = 0; i < clip.frames.length; i++) {
    if (t >= clip.frames[i].time) {
      chosen = clip.frames[i].slice;
    } else {
      break;
    }
  }
  return chosen;
}

export type SpriteAtlas = Record<string, HTMLImageElement>;

export async function loadAllSprites(): Promise<SpriteAtlas> {
  const paths = Array.from(new Set(Object.values(SPRITE_PATHS)));
  const entries = await Promise.all(
    paths.map(
      (src) =>
        new Promise<[string, HTMLImageElement]>((resolve, reject) => {
          const img = new Image();
          img.onload = () => resolve([src, img]);
          img.onerror = () => reject(new Error(`Failed to load sprite: ${src}`));
          img.src = src;
        }),
    ),
  );
  return Object.fromEntries(entries);
}
